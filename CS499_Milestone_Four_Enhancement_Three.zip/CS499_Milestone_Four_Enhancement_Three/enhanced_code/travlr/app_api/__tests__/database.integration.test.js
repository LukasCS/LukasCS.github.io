// Integration tests for CS 499 Enhancement Three (Databases):
// schema validation, the aggregation-pipeline query engine and its
// parity with the Enhancement Two application engine, role-based
// access control, NoSQL-injection sanitization, and catalog stats.
const { MongoMemoryServer } = require('mongodb-memory-server');
const mongoose = require('mongoose');
const express = require('express');
const request = require('supertest');
const fs = require('fs');
const path = require('path');

jest.setTimeout(120000);

let mongod;
let app;
let Trip;
let User;

beforeAll(async () => {
    mongod = await MongoMemoryServer.create();
    await mongoose.connect(mongod.getUri('travlr'));

    Trip = require('../models/travlr');
    User = require('../models/user');
    const seed = JSON.parse(
        fs.readFileSync(path.join(__dirname, '../../data/trips.json'), 'utf8')
    );
    await Trip.insertMany(seed);
    await Trip.createIndexes();

    process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret';
    require('../config/passport');
    const passport = require('passport');
    const sanitizeInputs = require('../middleware/sanitizeInputs');
    const apiRouter = require('../routes/index');
    app = express();
    app.use(express.json());
    app.use(passport.initialize());
    app.use('/api', sanitizeInputs);
    app.use('/api', apiRouter);
});

afterAll(async () => {
    await mongoose.disconnect();
    if (mongod) {
        await mongod.stop();
    }
});

async function makeToken(role) {
    const email = `${role}-${Date.now()}-${Math.random().toString(36).slice(2)}@test.com`;
    const res = await request(app)
        .post('/api/register')
        .send({ name: `${role} tester`, email, password: 'S3curePass!x' });
    expect(res.status).toBe(201);
    if (role === 'admin') {
        // Roles are never settable via the API; promote directly in the
        // database (mirroring scripts/promote-admin.js) and mint a
        // fresh token carrying the admin claim.
        const user = await User.findOneAndUpdate({ email }, { role: 'admin' }, { new: true });
        return user.generateJWT();
    }
    return res.body.token;
}

describe('schema validation (Mongoose layer)', () => {
    test('perPerson is stored as a Number, cast from the seed strings', async () => {
        const trip = await Trip.findOne({ code: 'GALR210214' }).lean();
        expect(typeof trip.perPerson).toBe('number');
        expect(trip.perPerson).toBe(799);
    });

    test('rejects a negative price with a 400 validation error', async () => {
        const token = await makeToken('admin');
        const res = await request(app)
            .post('/api/trips')
            .set('Authorization', `Bearer ${token}`)
            .send({
                code: 'BADP270101', name: 'Bad Price', length: '1 night / 2 days',
                start: '2027-01-01', resort: 'Test Resort, 3 stars',
                perPerson: -50, image: 'reef1.jpg', description: 'Invalid price test.'
            });
        expect(res.status).toBe(400);
        expect(res.body.message).toMatch(/negative/i);
    });

    test('rejects a path-traversal image filename', async () => {
        const token = await makeToken('admin');
        const res = await request(app)
            .post('/api/trips')
            .set('Authorization', `Bearer ${token}`)
            .send({
                code: 'BADI270101', name: 'Bad Image', length: '1 night / 2 days',
                start: '2027-01-01', resort: 'Test Resort, 3 stars',
                perPerson: 100, image: '../../etc/passwd', description: 'Traversal test.'
            });
        expect(res.status).toBe(400);
    });

    test('rejects a duplicate trip code with a client error', async () => {
        const token = await makeToken('admin');
        const res = await request(app)
            .post('/api/trips')
            .set('Authorization', `Bearer ${token}`)
            .send({
                code: 'GALR210214', name: 'Duplicate', length: '1 night / 2 days',
                start: '2027-01-01', resort: 'Test Resort, 3 stars',
                perPerson: 100, image: 'reef1.jpg', description: 'Duplicate code test.'
            });
        expect([400, 409, 500]).toContain(res.status);
        expect(res.status).toBeLessThan(501);
    });
});

describe('database query engine (aggregation + text index)', () => {
    test('default engine is db and returns the standard page shape', async () => {
        const res = await request(app).get('/api/trips/search?limit=6');
        expect(res.status).toBe(200);
        expect(res.body.engine).toBe('db');
        expect(res.body.results).toHaveLength(6);
        expect(res.body.totalMatches).toBe(27);
        expect(res.body.nextCursor).toBeTruthy();
    });

    test('db cursor pagination walks all 27 trips with no duplicates or gaps', async () => {
        const seen = [];
        let cursor = null;
        for (let page = 0; page < 7; page += 1) {
            const url = cursor
                ? `/api/trips/search?limit=5&cursor=${encodeURIComponent(cursor)}`
                : '/api/trips/search?limit=5';
            const res = await request(app).get(url);
            expect(res.status).toBe(200);
            seen.push(...res.body.results.map((t) => t.code));
            cursor = res.body.nextCursor;
            if (!cursor) break;
        }
        expect(seen).toHaveLength(27);
        expect(new Set(seen).size).toBe(27);
    });

    test('weighted text search ranks a name match above description matches', async () => {
        const res = await request(app).get('/api/trips/search?search=reef&limit=10');
        expect(res.status).toBe(200);
        expect(res.body.engine).toBe('db');
        expect(res.body.sortBy).toBe('relevance');
        expect(res.body.results[0].name.toLowerCase()).toContain('reef');
    });

    test('db and app engines agree on price ordering', async () => {
        const dbRes = await request(app).get('/api/trips/search?sortBy=price&limit=50&engine=db');
        const appRes = await request(app).get('/api/trips/search?sortBy=price&limit=50&engine=app');
        expect(dbRes.status).toBe(200);
        expect(appRes.status).toBe(200);
        expect(appRes.body.engine).toBe('app');
        expect(dbRes.body.results.map((t) => t.code))
            .toEqual(appRes.body.results.map((t) => t.code));
    });

    test('db engine rejects a malformed cursor with 400', async () => {
        const res = await request(app).get('/api/trips/search?cursor=%25%25%25');
        expect(res.status).toBe(400);
    });

    test('stats endpoint aggregates counts and price statistics by rating', async () => {
        const res = await request(app).get('/api/trips/stats');
        expect(res.status).toBe(200);
        expect(res.body.overall.totalTrips).toBe(27);
        expect(res.body.overall.minPrice).toBe(549);
        const ratings = res.body.byRating.map((r) => r.rating);
        expect(ratings).toEqual([...ratings].sort((a, b) => a - b));
        const threeStar = res.body.byRating.find((r) => r.rating === 3);
        expect(threeStar.count).toBeGreaterThan(0);
        expect(threeStar.avgPrice).toBeGreaterThan(0);
        const bandTotal = res.body.priceBands.reduce((sum, b) => sum + b.count, 0);
        expect(bandTotal).toBe(27);
    });
});

describe('role-based access control', () => {
    const newTrip = {
        code: 'RBAC270101', name: 'RBAC Test Trip', length: '2 nights / 3 days',
        start: '2027-01-01', resort: 'Test Resort, 3 stars',
        perPerson: 500, image: 'reef1.jpg', description: 'Created by an admin in the RBAC test.'
    };

    test('anonymous mutation is rejected with 401', async () => {
        const res = await request(app).post('/api/trips').send(newTrip);
        expect(res.status).toBe(401);
    });

    test('an ordinary user is rejected with 403', async () => {
        const token = await makeToken('user');
        const res = await request(app)
            .post('/api/trips')
            .set('Authorization', `Bearer ${token}`)
            .send(newTrip);
        expect(res.status).toBe(403);
        expect(res.body.message).toMatch(/admin/);
    });

    test('an admin can create, update, and delete a trip', async () => {
        const token = await makeToken('admin');
        const created = await request(app)
            .post('/api/trips')
            .set('Authorization', `Bearer ${token}`)
            .send(newTrip);
        expect(created.status).toBe(201);
        expect(created.body.perPerson).toBe(500);

        const updated = await request(app)
            .put(`/api/trips/${newTrip.code}`)
            .set('Authorization', `Bearer ${token}`)
            .send({ ...newTrip, perPerson: 550 });
        expect(updated.status).toBe(200);
        expect(updated.body.perPerson).toBe(550);

        const deleted = await request(app)
            .delete(`/api/trips/${newTrip.code}`)
            .set('Authorization', `Bearer ${token}`)
            .send();
        expect(deleted.status).toBe(204);
    });

    test('registration ignores a role smuggled into the request body', async () => {
        const email = `massassign-${Date.now()}@test.com`;
        const res = await request(app)
            .post('/api/register')
            .send({ name: 'Sneaky', email, password: 'S3curePass!x', role: 'admin' });
        expect(res.status).toBe(201);
        const user = await User.findOne({ email }).lean();
        expect(user.role).toBe('user');
    });
});

describe('NoSQL injection defenses', () => {
    test('operator-object credentials are rejected at login', async () => {
        const res = await request(app)
            .post('/api/login')
            .send({ email: { $gt: '' }, password: { $gt: '' } });
        expect(res.status).toBe(400);
        expect(res.body.message).toMatch(/text values/i);
    });

    test('dollar-prefixed keys are stripped from stored documents', async () => {
        const token = await makeToken('admin');
        const res = await request(app)
            .post('/api/trips')
            .set('Authorization', `Bearer ${token}`)
            .send({
                code: 'INJT270101', name: 'Injection Test', length: '2 nights / 3 days',
                start: '2027-01-01', resort: 'Test Resort, 3 stars',
                perPerson: 400, image: 'reef1.jpg',
                description: 'A trip that costs $400 total.',
                $where: 'sleep(1000)'
            });
        expect(res.status).toBe(201);
        const stored = await Trip.findOne({ code: 'INJT270101' }).lean();
        expect(stored.$where).toBeUndefined();
        // Dollar signs in VALUES are legitimate data and survive.
        expect(stored.description).toContain('$400');
        await Trip.deleteOne({ code: 'INJT270101' });
    });
});
