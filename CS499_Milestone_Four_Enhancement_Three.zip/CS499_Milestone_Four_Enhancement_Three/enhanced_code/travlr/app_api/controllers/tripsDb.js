// Database-engine query controllers — CS 499 Enhancement Three.
//
// These implement the SAME contract as the Enhancement Two
// application-level engine (search, sort, cursor pagination) but push
// the work into MongoDB itself: $text against a weighted index for
// relevance, $sort with a case-insensitive collation for ordering,
// range-based $match conditions for cursor resumption, and $facet to
// return the page and the total in one round trip. The point of
// keeping both engines is the direct comparison the Milestone Three
// narrative promised: identical behavior, different placement of the
// work, different scaling characteristics (the database engine sorts
// on indexes and never ships the full collection to the application).
const mongoose = require('mongoose');
require('../models/travlr');
const Model = mongoose.model('trips');
const { ApiError } = require('../middleware/errorHandler');
const { encodeCursor, decodeCursor } = require('../algorithms/cursor');

const DEFAULT_LIMIT = 6;
const MAX_LIMIT = 50;
const SORT_FIELDS = new Set(['name', 'price', 'start', 'relevance']);

// Case-insensitive comparisons so 'alpine' and 'Alpine' sort together,
// matching the application engine's toLowerCase() behavior.
const NAME_COLLATION = { locale: 'en', strength: 2 };

function parseCommonParams(req) {
    const query = typeof req.query.search === 'string' ? req.query.search.trim().slice(0, 100) : '';
    let sortBy = typeof req.query.sortBy === 'string' ? req.query.sortBy : '';
    if (sortBy && !SORT_FIELDS.has(sortBy)) {
        throw new ApiError(400, `Unsupported sortBy value: must be one of ${[...SORT_FIELDS].join(', ')}`);
    }
    if (!sortBy) {
        sortBy = query ? 'relevance' : 'name';
    }
    if (sortBy === 'relevance' && !query) {
        sortBy = 'name';
    }
    const order = req.query.order === 'desc' ? 'desc' : 'asc';
    let limit = Number.parseInt(req.query.limit, 10);
    if (!Number.isInteger(limit)) {
        limit = DEFAULT_LIMIT;
    }
    limit = Math.max(1, Math.min(MAX_LIMIT, limit));
    return { query, sortBy, order, limit };
}

// Maps the public sort field to the document field the pipeline uses.
function sortFieldFor(sortBy) {
    switch (sortBy) {
        case 'price': return 'perPerson';
        case 'start': return 'start';
        case 'relevance': return 'textScore';
        default: return 'name';
    }
}

/**
 * Runs search + sort + cursor pagination entirely inside MongoDB.
 * Pipeline shape:
 *   [$match ($text)] -> [$addFields textScore] -> $facet {
 *     total: [$count],
 *     page:  [cursor $match] -> $sort -> $limit
 *   }
 */
async function runDbSearch({ query, sortBy, order, limit, cursor }) {
    const direction = sortBy === 'relevance' ? -1 : (order === 'desc' ? -1 : 1);
    const field = sortFieldFor(sortBy);

    const pipeline = [];
    if (query) {
        pipeline.push({ $match: { $text: { $search: query } } });
        pipeline.push({ $addFields: { textScore: { $meta: 'textScore' } } });
    }

    // Cursor resumption as a range condition on (sort value, code):
    // strictly-past-the-anchor OR same-sort-value-and-later-code.
    const pageStages = [];
    if (cursor) {
        const position = decodeCursor(cursor, { sortBy, order, query });
        const past = direction === 1 ? '$gt' : '$lt';
        const value = field === 'start' ? new Date(position.value) : position.value;
        pageStages.push({
            $match: {
                $or: [
                    { [field]: { [past]: value } },
                    { [field]: value, code: { $gt: position.code } }
                ]
            }
        });
    }
    pageStages.push({ $sort: { [field]: direction, code: 1 } });
    pageStages.push({ $limit: limit + 1 }); // one extra to detect a next page
    pageStages.push({ $project: { textScore: 0 } });

    pipeline.push({
        $facet: {
            total: [{ $count: 'n' }],
            page: pageStages
        }
    });

    const [result] = await Model
        .aggregate(pipeline)
        .collation(NAME_COLLATION)
        .exec();

    const totalMatches = result.total.length > 0 ? result.total[0].n : 0;
    const hasMore = result.page.length > limit;
    const page = hasMore ? result.page.slice(0, limit) : result.page;

    let nextCursor = null;
    if (hasMore && page.length > 0) {
        const last = page[page.length - 1];
        // Recompute the last item's sort value for the cursor. For
        // relevance we re-run the score via a covered lookup below.
        let sortValue;
        if (sortBy === 'relevance') {
            const rescored = await Model
                .findOne({ code: last.code, $text: { $search: query } }, { score: { $meta: 'textScore' } })
                .lean().exec();
            sortValue = rescored ? rescored.score : 0;
        } else if (field === 'start') {
            sortValue = new Date(last.start).toISOString();
        } else {
            sortValue = last[field];
        }
        nextCursor = encodeCursor({ sortBy, order, query }, { sortValue, code: last.code });
    }

    return { results: page, totalMatches, nextCursor, sortBy, order };
}

/**
 * Catalog statistics via a single aggregation pipeline — the classic
 * "let the database do the analytics" showcase. $regexFind extracts
 * the star rating embedded in the resort string, $group computes
 * per-rating counts and price statistics (possible only because
 * Enhancement Three made perPerson a Number), and a parallel $bucket
 * groups the catalog into price bands.
 */
async function runCatalogStats() {
    const [result] = await Model.aggregate([
        {
            $addFields: {
                rating: {
                    $let: {
                        vars: { found: { $regexFind: { input: '$resort', regex: /(\d+)\s*stars?/i } } },
                        in: {
                            $cond: [
                                { $ne: ['$$found', null] },
                                { $toInt: { $arrayElemAt: ['$$found.captures', 0] } },
                                null
                            ]
                        }
                    }
                }
            }
        },
        {
            $facet: {
                byRating: [
                    { $match: { rating: { $ne: null } } },
                    {
                        $group: {
                            _id: '$rating',
                            count: { $sum: 1 },
                            avgPrice: { $avg: '$perPerson' },
                            minPrice: { $min: '$perPerson' },
                            maxPrice: { $max: '$perPerson' }
                        }
                    },
                    { $sort: { _id: 1 } },
                    {
                        $project: {
                            _id: 0,
                            rating: '$_id',
                            count: 1,
                            avgPrice: { $round: ['$avgPrice', 2] },
                            minPrice: 1,
                            maxPrice: 1
                        }
                    }
                ],
                priceBands: [
                    {
                        $bucket: {
                            groupBy: '$perPerson',
                            boundaries: [0, 1000, 2000, 3000, 1000000],
                            default: 'other',
                            output: { count: { $sum: 1 } }
                        }
                    }
                ],
                overall: [
                    {
                        $group: {
                            _id: null,
                            totalTrips: { $sum: 1 },
                            avgPrice: { $avg: '$perPerson' },
                            minPrice: { $min: '$perPerson' },
                            maxPrice: { $max: '$perPerson' }
                        }
                    },
                    {
                        $project: {
                            _id: 0,
                            totalTrips: 1,
                            avgPrice: { $round: ['$avgPrice', 2] },
                            minPrice: 1,
                            maxPrice: 1
                        }
                    }
                ]
            }
        }
    ]).exec();

    return {
        overall: result.overall[0] || { totalTrips: 0 },
        byRating: result.byRating,
        priceBands: result.priceBands.map((band) => ({
            from: band._id === 'other' ? null : band._id,
            count: band.count
        }))
    };
}

module.exports = { parseCommonParams, runDbSearch, runCatalogStats };
