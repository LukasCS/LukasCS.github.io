// Trip interface — direct TypeScript port of the Angular model
// (app_admin/src/app/models/trip.ts). Interfaces give compile-time
// type safety across the API layer, context, and components.
export interface Trip {
  _id: string;
  code: string;
  name: string;
  length: string;
  start: string; // ISO date string as returned by the Express API
  resort: string;
  perPerson: number; // Enhancement Three: schema stores a Number now
  image: string;
  description: string;
}

// Shape of the add/edit form before a trip has an _id assigned by
// MongoDB. Form inputs are text, so the draft keeps perPerson as a
// string; TripForm converts it to a number at submit time to match
// the Enhancement Three schema type.
export type TripFormData = Omit<Trip, '_id' | 'perPerson'> & {
  _id?: string;
  perPerson: string;
};

// Converts a validated form draft into the API payload shape.
export function toTripPayload(form: TripFormData): Omit<Trip, '_id'> & { _id?: string } {
  return { ...form, perPerson: Number(form.perPerson) };
}
