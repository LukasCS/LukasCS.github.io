// Add Trip page. The Angular AddTripComponent owned a full FormGroup
// and template; here the page is reduced to wiring the shared
// TripForm to the addTrip API call and navigating home on success.
import { useNavigate } from 'react-router-dom';
import TripForm from '../components/TripForm';
import { addTrip } from '../api/trip-api';
import { TripFormData } from '../models/trip';

export default function AddTrip() {
  const navigate = useNavigate();

  const handleSubmit = async (formData: TripFormData) => {
    await addTrip(formData);
    navigate('/');
  };

  return <TripForm title="Add Trip" onSubmit={handleSubmit} />;
}
