// Typed CRUD functions for the /api/trips endpoints.
//
// This is the React counterpart of Angular's TripDataService. Instead
// of an injectable class returning RxJS Observables, each operation is
// a plain async function returning a typed Promise. Components consume
// these with async/await inside useEffect or event handlers, which
// removes the subscribe/unsubscribe lifecycle management entirely.
import apiClient from './client';
import { Trip, TripFormData } from '../models/trip';

export async function getTrips(): Promise<Trip[]> {
  const response = await apiClient.get<Trip[]>('/trips');
  return response.data;
}

// The Express API returns an array even for a single-code lookup, so
// this normalizes to one record (or null) at the API boundary instead
// of forcing every caller to remember that quirk, as the Angular
// EditTripComponent had to.
export async function getTrip(tripCode: string): Promise<Trip | null> {
  const response = await apiClient.get<Trip[]>(`/trips/${tripCode}`);
  return Array.isArray(response.data) ? response.data[0] ?? null : response.data;
}

export async function addTrip(formData: TripFormData): Promise<Trip> {
  const response = await apiClient.post<Trip>('/trips', formData);
  return response.data;
}

export async function updateTrip(formData: TripFormData): Promise<Trip> {
  const response = await apiClient.put<Trip>(
    `/trips/${formData.code}`,
    formData
  );
  return response.data;
}

export async function deleteTrip(tripCode: string): Promise<void> {
  await apiClient.delete(`/trips/${tripCode}`);
}
