// Trip interface — direct TypeScript port of the Angular model
// (app_admin/src/app/models/trip.ts). Interfaces give compile-time
// type safety across the API layer, context, and components.
export interface Trip {
  _id: string;
  code: string;
  name: string;
  length: string;
  start: string; // ISO date string as returned by the Express API
  resort: string;
  perPerson: string;
  image: string;
  description: string;
}

// Shape of the add/edit form before a trip has an _id assigned by MongoDB.
export type TripFormData = Omit<Trip, '_id'> & { _id?: string };
