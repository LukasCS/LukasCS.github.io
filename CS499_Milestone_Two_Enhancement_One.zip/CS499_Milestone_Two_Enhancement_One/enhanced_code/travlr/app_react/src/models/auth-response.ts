// Response returned by POST /api/login and POST /api/register.
export interface AuthResponse {
  token: string;
}
