import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The React admin SPA runs on port 4200 (same port the Angular CLI used)
// so the Express backend CORS configuration does not need to change.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 4200
  }
});
