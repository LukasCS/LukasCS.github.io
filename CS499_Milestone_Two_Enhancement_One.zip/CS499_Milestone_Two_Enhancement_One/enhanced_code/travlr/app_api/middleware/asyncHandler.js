// Wraps an async route handler so any thrown error or rejected promise
// is forwarded to Express's centralized error-handling middleware.
//
// Motivation from the code review: every controller in trips.js
// referenced an undefined variable `err` in its failure branches
// (lines 21, 45, 78, 119 of the original file), which would itself
// throw a ReferenceError, and rejected promises from Mongoose escaped
// Express 4's error pipeline entirely, crashing the process. With this
// wrapper, controllers contain only the success path and all failures
// converge on one error handler.
const asyncHandler = (handler) => (req, res, next) => {
    Promise.resolve(handler(req, res, next)).catch(next);
};

module.exports = asyncHandler;
