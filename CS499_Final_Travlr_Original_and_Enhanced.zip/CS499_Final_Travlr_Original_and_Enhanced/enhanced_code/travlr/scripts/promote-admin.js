// Promotes an existing user to the admin role.
// Usage: node scripts/promote-admin.js user@example.com
//
// Roles can never be set through the public API (registration ignores
// any role in the request body), so this operator-run script is the
// single, auditable path to admin privileges. The user must log in
// again after promotion so a fresh JWT carries the new role claim.
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../app_api/models/user');

async function main() {
    const email = process.argv[2];
    if (!email) {
        console.error('Usage: node scripts/promote-admin.js <email>');
        process.exit(1);
    }
    const host = process.env.DB_HOST || '127.0.0.1';
    await mongoose.connect(`mongodb://${host}/travlr`);
    const user = await User.findOneAndUpdate(
        { email: email.toLowerCase() },
        { role: 'admin' },
        { new: true }
    );
    if (!user) {
        console.error(`No user found with email ${email}`);
    } else {
        console.log(`${user.email} is now role: ${user.role}. Log in again to receive a token with the new role.`);
    }
    await mongoose.disconnect();
}

main().catch((error) => { console.error(error); process.exit(1); });
