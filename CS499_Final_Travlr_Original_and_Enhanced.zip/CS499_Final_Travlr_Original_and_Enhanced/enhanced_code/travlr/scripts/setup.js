// One-command project bootstrap: checks MongoDB, installs both
// dependency trees, creates a working .env with a real secret, and
// seeds the database. Everything this script does is exactly the
// manual setup documented in README.md, automated and narrated step
// by step so a reader can see what happened (and why) if anything
// goes wrong.
//
// Usage: node scripts/setup.js   (run from the travlr/ folder)
//
// No dependencies beyond Node's own standard library — this has to
// run before `npm install` has populated node_modules, so it can't
// rely on anything from package.json.
const net = require('net');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

// The backend tests use an in-memory MongoDB whose server executable
// is downloaded once, during npm install, by the mongodb-memory-server
// package. Left to its default it stores that executable inside
// node_modules/.cache, where on Windows the full path can pass the
// operating system's 260-character limit if this project sits in a
// deeply nested folder — Windows then refuses to start the executable.
// Storing it in the system temporary folder keeps its path short from
// any location. jest.setup.js sets the same location for the tests
// themselves, so the copy downloaded here is the copy the tests use.
if (!process.env.MONGOMS_DOWNLOAD_DIR) {
    process.env.MONGOMS_DOWNLOAD_DIR = path.join(
        os.tmpdir(),
        'mongodb-memory-server-binaries'
    );
}

const ROOT = path.join(__dirname, '..');
const BACKEND_DIR = ROOT;
const FRONTEND_DIR = path.join(ROOT, 'app_react');

function step(message) {
    console.log(`\n==> ${message}`);
}

function fail(message) {
    console.error(`\nSetup stopped: ${message}`);
    process.exit(1);
}

// Opens a raw TCP connection to the default MongoDB port. This is
// deliberately not a MongoDB driver call: mongoose isn't installed
// yet at this point in a first-time setup, and a plain socket check
// answers the only question that matters here — is anything
// listening — without pulling in a dependency just to fail fast.
function checkMongoReachable(host, port, timeoutMs) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        let settled = false;

        const finish = (reachable) => {
            if (settled) return;
            settled = true;
            socket.destroy();
            resolve(reachable);
        };

        socket.setTimeout(timeoutMs);
        socket.once('connect', () => finish(true));
        socket.once('timeout', () => finish(false));
        socket.once('error', () => finish(false));
        socket.connect(port, host);
    });
}

// Runs a command and streams its output straight to this terminal
// (stdio: 'inherit') instead of buffering it, so a slow `npm install`
// still shows progress instead of looking hung.
function run(command, args, cwd) {
    // On Windows, npm is a .cmd batch shim rather than a real
    // executable. Since Node 20.12 / 22 / 24, Node refuses to launch a
    // .cmd file unless the call goes through the command interpreter,
    // so `shell: true` is required here rather than optional. The
    // command and arguments below are all fixed strings written in this
    // file — nothing comes from user input — so there is no argument
    // injection risk in handing them to the shell.
    // The command and its arguments are joined into one string rather
    // than passed as a separate array. With shell: true, Node warns
    // that a separate array is not escaped before being concatenated,
    // and joining here does the concatenation openly instead of
    // relying on that behaviour.
    const commandLine = [command, ...args].join(' ');
    const result = spawnSync(commandLine, { cwd, stdio: 'inherit', shell: true });

    // Two different failures are possible and they need different
    // messages: the command could not be started at all (result.error),
    // or it ran and reported a problem (a non-zero exit status). Both
    // are reported with the underlying detail, because a bare "it
    // failed" leaves the reader with nothing to act on.
    if (result.error) {
        fail(
            `Could not start "${command} ${args.join(' ')}" in ${cwd}.\n` +
            `Reason: ${result.error.message}\n` +
            `Check that "${command}" is installed and available on your PATH.`
        );
    }
    if (result.status !== 0) {
        fail(
            `"${command} ${args.join(' ')}" exited with code ${result.status} in ${cwd}.\n` +
            'The output above this message shows what went wrong.'
        );
    }
}

function installIfNeeded(label, dir) {
    const nodeModules = path.join(dir, 'node_modules');
    if (fs.existsSync(nodeModules)) {
        console.log(`${label}: node_modules already present, skipping npm install.`);
        return;
    }
    console.log(`${label}: node_modules not found, running npm install...`);
    run('npm', ['install'], dir);
}

// Creates .env from .env.sample the first time setup runs, replacing
// the placeholder JWT secret with a freshly generated random value so
// nobody ends up running with the sample's well-known placeholder
// text as their real signing key. An existing .env is left completely
// alone — it may hold values a developer already customized.
function createEnvIfMissing() {
    const envPath = path.join(BACKEND_DIR, '.env');
    const samplePath = path.join(BACKEND_DIR, '.env.sample');

    if (fs.existsSync(envPath)) {
        console.log('.env already exists, leaving it untouched.');
        return;
    }

    const sample = fs.readFileSync(samplePath, 'utf8');
    const secret = crypto.randomBytes(32).toString('hex'); // 64 hex characters
    const generated = sample.replace(
        /^JWT_SECRET=.*$/m,
        `JWT_SECRET=${secret}`
    );
    fs.writeFileSync(envPath, generated);
    console.log('.env created from .env.sample with a freshly generated JWT_SECRET.');
}

async function main() {
    console.log('Travlr Getaways setup');
    console.log('======================');

    step('Checking for MongoDB on 127.0.0.1:27017...');
    const mongoUp = await checkMongoReachable('127.0.0.1', 27017, 2000);
    if (!mongoUp) {
        fail(
            'MongoDB is not reachable on 127.0.0.1:27017. Start your local MongoDB ' +
            'server first, then run "npm run setup" again. (If MongoDB uses a ' +
            'different host or port on this machine, connect it to the default ' +
            'local port before continuing, or run the manual setup steps in ' +
            'README.md instead.)'
        );
    }
    console.log('MongoDB is reachable.');

    step('Installing backend dependencies (travlr/)...');
    installIfNeeded('Backend', BACKEND_DIR);

    step('Installing frontend dependencies (travlr/app_react/)...');
    installIfNeeded('Frontend', FRONTEND_DIR);

    step('Setting up .env...');
    createEnvIfMissing();

    step('Seeding the database...');
    run('node', ['app_api/models/seed.js'], BACKEND_DIR);
    console.log('Database seeded with sample trips.');

    step('Setup complete.');
    console.log('Next, run:');
    console.log('  npm run dev');
    console.log('\nThat starts the backend and the admin frontend together. Once both are up:');
    console.log('  Customer site + API: http://localhost:3000');
    console.log('  Admin app:           http://localhost:4200');
}

main();
