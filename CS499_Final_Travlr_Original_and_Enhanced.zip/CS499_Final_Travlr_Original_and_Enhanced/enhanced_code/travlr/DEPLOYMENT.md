# Deploying Travlr Getaways to a public server

This guide puts the application on a single Ubuntu server reachable over
HTTPS. It was written against DigitalOcean and DuckDNS, but nothing here
depends on either: any provider that gives you an Ubuntu machine with a
public address, and any name that can point at that address, works the
same way.

Everything in this guide is run over SSH on the server, except where a
step says to run it on your own machine.

## What the finished setup looks like

| Piece | Where it runs | Reached at |
|---|---|---|
| Express backend, the API, and the server-rendered customer site | The server, listening on 127.0.0.1 port 3000 | `https://<your-name>.duckdns.org` |
| The React admin application, built to static files | Served from disk by the web server | `https://<your-name>-admin.duckdns.org` |
| MongoDB | The server, listening on 127.0.0.1 only | Not reachable from outside |
| Caddy web server | The server, ports 80 and 443 | Obtains and renews the HTTPS certificate by itself |

The backend is never exposed directly. Caddy holds the public ports,
terminates HTTPS, and passes requests to the backend over the machine's
own loopback address. MongoDB keeps its default setting of listening
only on the loopback address, so it has no public exposure at all.

## Before you start

You need:

- A domain name or subdomain you can point at an address. A free
  DuckDNS name is enough, and this guide uses two of them.
- An SSH key pair on your own machine. If you do not have one:
  `ssh-keygen -t ed25519 -C "your.email@example.com"`.
- The application's code archive.

## 1. Create the server

On DigitalOcean, choose **Create → Droplet** and set:

| Setting | Value | Why |
|---|---|---|
| Image | Ubuntu 24.04 LTS | Long-term support release; every command below assumes it |
| Type | Basic, Regular SSD | The cheapest tier that is enough |
| Size | 2 GB memory, 1 CPU, 50 GB disk | About $12 a month. The 1 GB size is not enough: MongoDB and the Node.js build together exceed it and the build is killed part-way |
| Region | The one closest to you | Only affects speed |
| Authentication | SSH key | Password login is weaker and is switched off in step 2 |
| Hostname | `travlr` | Only a label |

Under **Advanced options**, enable monitoring if you want graphs. Nothing
else is needed.

When it finishes, note the public address DigitalOcean shows. This guide
writes it as `SERVER_IP`.

Add a firewall so only the ports you need are open. In DigitalOcean's
**Networking → Firewalls**, create one that allows inbound SSH (22),
HTTP (80), and HTTPS (443), leaves all outbound traffic allowed, and
apply it to the droplet.

## 2. First login and a working account

Log in as root:

```bash
ssh root@SERVER_IP
```

Update the system and create an ordinary account for yourself, so you
are not working as root:

```bash
apt update && apt upgrade -y
adduser --gecos "" lukas
usermod -aG sudo lukas
rsync --archive --chown=lukas:lukas ~/.ssh /home/lukas
```

Switch off password login and root login over SSH:

```bash
sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
systemctl restart ssh
```

**Before closing this session**, open a second terminal and confirm
`ssh lukas@SERVER_IP` works. If it does not, you still have the first
session open to undo the change. Once confirmed, do the rest as `lukas`.

## 3. Point two names at the server

Sign in at <https://www.duckdns.org> with any of the accounts it offers.
Create two subdomains, for example:

- `travlr-cs499` — the customer site and API
- `travlr-cs499-admin` — the admin application

Set the IP field of both to `SERVER_IP` and press update. Confirm from
your own machine:

```bash
nslookup travlr-cs499.duckdns.org
```

It must answer with `SERVER_IP` before you continue. Certificate issuing
in step 8 fails if the name does not yet resolve.

Wherever the rest of this guide writes `travlr-cs499.duckdns.org` or
`travlr-cs499-admin.duckdns.org`, substitute your own names.

## 4. Install Node.js

Ubuntu's own package is older than this application needs. Install the
current long-term-support release from NodeSource:

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node --version    # expect v22.x
```

## 5. Install MongoDB

```bash
curl -fsSL https://www.mongodb.org/static/pgp/server-8.0.asc \
  | sudo gpg -o /usr/share/keyrings/mongodb-server-8.0.gpg --dearmor
echo "deb [ arch=amd64,arm64 signed-by=/usr/share/keyrings/mongodb-server-8.0.gpg ] https://repo.mongodb.org/apt/ubuntu noble/mongodb-org/8.0 multiverse" \
  | sudo tee /etc/apt/sources.list.d/mongodb-org-8.0.list
sudo apt update
sudo apt install -y mongodb-org
sudo systemctl enable --now mongod
sudo systemctl status mongod --no-pager
```

Confirm it is listening on the loopback address only:

```bash
sudo ss -lntp | grep 27017     # expect 127.0.0.1:27017, not 0.0.0.0:27017
```

That is MongoDB's default and it is what you want. Do not change it.

## 6. Put the application on the server

From **your own machine**, copy the archive up:

```bash
scp CS499_Final_Travlr_Original_and_Enhanced.zip lukas@SERVER_IP:~
```

Back on the server:

```bash
sudo apt install -y unzip
unzip -q ~/CS499_Final_Travlr_Original_and_Enhanced.zip -d ~/upload
sudo mkdir -p /opt/travlr
sudo cp -r ~/upload/CS499_Final_Travlr_Original_and_Enhanced/enhanced_code/travlr/. /opt/travlr/
sudo chown -R lukas:lukas /opt/travlr
cd /opt/travlr
npm install --omit=dev
```

Create the settings file. The signing key must be a fresh random value
that exists nowhere else:

```bash
cd /opt/travlr
printf 'JWT_SECRET=%s\n' "$(openssl rand -hex 32)" > .env
printf 'ALLOWED_ORIGIN=https://travlr-cs499-admin.duckdns.org\n' >> .env
chmod 600 .env
```

`ALLOWED_ORIGIN` is the single browser origin the API accepts requests
from. It must be the admin application's address exactly, including
`https://` and with no trailing slash.

Load the sample trips:

```bash
cd /opt/travlr
node app_api/models/seed.js
```

## 7. Keep the backend running

Create the service definition:

```bash
sudo tee /etc/systemd/system/travlr.service > /dev/null <<'EOF'
[Unit]
Description=Travlr Getaways backend
After=network.target mongod.service
Requires=mongod.service

[Service]
Type=simple
User=lukas
WorkingDirectory=/opt/travlr
Environment=NODE_ENV=production
ExecStart=/usr/bin/node ./bin/www
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now travlr
sudo systemctl status travlr --no-pager
curl -s localhost:3000/api/trips | head -c 200; echo
```

The last command must print trip data. If it does not, read the log with
`sudo journalctl -u travlr -n 50 --no-pager`.

## 8. Build the admin application

The admin application is a set of static files. It is built once, with
the API's public address fixed into the bundle:

```bash
cd /opt/travlr/app_react
npm install
VITE_API_BASE_URL=https://travlr-cs499.duckdns.org/api npm run build
sudo mkdir -p /var/www/travlr-admin
sudo cp -r dist/. /var/www/travlr-admin/
```

If you later change the API's address, rebuild with the new value and
copy the result again. The address is fixed at build time, not read
while the application runs.

## 9. Install the web server and turn on HTTPS

```bash
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https curl
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
  | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
  | sudo tee /etc/apt/sources.list.d/caddy-stable.list
sudo apt update && sudo apt install -y caddy
```

Write the configuration:

```bash
sudo tee /etc/caddy/Caddyfile > /dev/null <<'EOF'
travlr-cs499.duckdns.org {
    encode gzip
    reverse_proxy 127.0.0.1:3000
}

travlr-cs499-admin.duckdns.org {
    encode gzip
    root * /var/www/travlr-admin
    # The admin application handles its own page addresses, so any
    # address that is not a real file must be answered with the single
    # page rather than with a not-found error.
    try_files {path} /index.html
    file_server
}
EOF

sudo systemctl reload caddy
sudo systemctl status caddy --no-pager
```

Caddy requests the HTTPS certificates itself the first time each name is
visited, and renews them from then on. Nothing else is needed. If a
certificate fails, the cause is almost always that the name does not yet
point at this server — check step 3 again.

## 10. Check it works

From your own machine, open in a browser:

- `https://travlr-cs499.duckdns.org` — the customer site, with the
  padlock shown
- `https://travlr-cs499.duckdns.org/travel` — all trips, each with a
  photograph
- `https://travlr-cs499.duckdns.org/contact` — send a message and
  confirm the thank-you reply
- `https://travlr-cs499-admin.duckdns.org` — the catalogue, search,
  sorting, filters, and recommendations
- Register an account there, log in, and rate a trip

If the admin application loads but shows no trips, the browser's
developer console will say the request was blocked. That means
`ALLOWED_ORIGIN` in `/opt/travlr/.env` does not exactly match the admin
address. Correct it and run `sudo systemctl restart travlr`.

## 11. Protecting a public demonstration

Anyone who finds the address can use it. Two facts limit what a stranger
can do, and one measure covers the rest.

- **Creating, editing, and deleting trips is refused** for every account
  unless that account holds the administrator role, and the only way to
  grant that role is to run a script on this server. A visitor cannot
  give it to themselves.
- **What a visitor can do** is register an account, rate trips, and send
  contact messages.

To keep the catalogue and the message list tidy regardless, reload the
sample data every hour:

```bash
sudo tee /etc/systemd/system/travlr-reseed.service > /dev/null <<'EOF'
[Unit]
Description=Reload the Travlr sample trips
After=mongod.service

[Service]
Type=oneshot
User=lukas
WorkingDirectory=/opt/travlr
ExecStart=/usr/bin/node app_api/models/seed.js
EOF

sudo tee /etc/systemd/system/travlr-reseed.timer > /dev/null <<'EOF'
[Unit]
Description=Reload the Travlr sample trips every hour

[Timer]
OnCalendar=hourly
Persistent=true

[Install]
WantedBy=timers.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now travlr-reseed.timer
systemctl list-timers travlr-reseed --no-pager
```

To give a reviewer the administrator view, create an account through the
admin application in the normal way, then promote it on the server:

```bash
cd /opt/travlr
node scripts/promote-admin.js reviewer@example.com
```

The reviewer must log out and log back in afterwards: the role is
carried in the login token, so a session opened before promotion does
not pick it up.

## 12. Everyday operation

| Task | Command |
|---|---|
| Read the backend log | `sudo journalctl -u travlr -f` |
| Restart the backend | `sudo systemctl restart travlr` |
| Reload the sample trips now | `cd /opt/travlr && node app_api/models/seed.js` |
| Check the certificate and web server | `sudo systemctl status caddy` |
| Apply system updates | `sudo apt update && sudo apt upgrade -y` |

To publish a new version of the code: copy the new files into
`/opt/travlr`, run `npm install --omit=dev`, rebuild the admin
application as in step 8, then `sudo systemctl restart travlr`. The
`.env` file is not part of the code archive and is left alone.

## 13. Shutting it down

Charges continue for as long as the server exists, whether or not it is
powered on. To stop them, destroy the droplet from the DigitalOcean
control panel; powering it off is not enough. Delete the two DuckDNS
names as well, so they stop pointing at an address you no longer own.
