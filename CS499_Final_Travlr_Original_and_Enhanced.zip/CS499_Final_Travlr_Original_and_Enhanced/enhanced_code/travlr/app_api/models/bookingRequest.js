const mongoose = require('mongoose');

// Booking request schema — backs the customer site's "Book this trip"
// form (POST /api/bookings). A booking request is an enquiry, not a
// confirmed sale: it records who wants to travel, on which trip, and
// how many people, so a travel adviser can reply. It deliberately
// stores no payment information.
//
// Validation lives in the schema for the same reason it does in
// travlr.js and contactMessage.js: the database is the last line every
// write passes through, so a controller that forgets a check cannot
// let malformed data in. tripCode and tripName are copied from the
// trip at the moment of the request rather than referenced, so the
// record still reads correctly if the catalog entry is later renamed
// or removed.
const bookingRequestSchema = new mongoose.Schema({
    tripCode: {
        type: String,
        required: [true, 'Trip code is required'],
        trim: true,
        uppercase: true,
        match: [/^[A-Z0-9]{4,12}$/, 'Trip code must be 4-12 uppercase letters or digits']
    },
    tripName: {
        type: String,
        required: [true, 'Trip name is required'],
        trim: true,
        maxlength: [120, 'Trip name cannot exceed 120 characters']
    },
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
        maxlength: [100, 'Name cannot exceed 100 characters']
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        trim: true,
        lowercase: true,
        maxlength: [200, 'Email cannot exceed 200 characters'],
        match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Email must be a valid address']
    },
    travellers: {
        type: Number,
        required: [true, 'Number of travellers is required'],
        min: [1, 'A booking needs at least one traveller'],
        max: [20, 'For more than 20 travellers please contact us directly']
    },
    notes: {
        type: String,
        trim: true,
        maxlength: [1000, 'Notes cannot exceed 1000 characters'],
        default: ''
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const BookingRequest = mongoose.model('bookingrequests', bookingRequestSchema);
module.exports = BookingRequest;
