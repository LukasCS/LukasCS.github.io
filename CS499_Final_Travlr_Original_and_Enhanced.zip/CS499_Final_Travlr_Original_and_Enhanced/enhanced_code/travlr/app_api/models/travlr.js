const mongoose = require('mongoose');

// Trip schema — CS 499 Enhancement Three (Databases).
//
// The original schema declared every field as a required String and
// nothing else, which pushed all data-integrity responsibility up
// into application code. This version moves validation into the
// database layer where it belongs:
//
//   - perPerson is now a Number (the code review flagged the String
//     type: prices stored as strings sort lexically and cannot be
//     aggregated). Mongoose casts numeric strings on write, and the
//     min validator rejects negative prices at the schema boundary.
//   - code is constrained to the catalog's identifier format and
//     indexed unique, so duplicate trip codes are impossible even if
//     a future controller forgets to check.
//   - image accepts only a bare image filename, which prevents path
//     traversal values (e.g. ../../etc/passwd) from ever being
//     stored and later served.
//   - A weighted text index over name, resort, and description powers
//     database-side relevance search. The weights (3/2/1) deliberately
//     mirror the application-level scorer from Enhancement Two so the
//     two implementations are directly comparable.
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: [true, 'Trip code is required'],
        unique: true,
        trim: true,
        uppercase: true,
        match: [/^[A-Z0-9]{4,12}$/, 'Trip code must be 4-12 uppercase letters or digits']
    },
    name: {
        type: String,
        required: [true, 'Trip name is required'],
        trim: true,
        maxlength: [120, 'Trip name cannot exceed 120 characters'],
        index: true
    },
    length: {
        type: String,
        required: [true, 'Trip length is required'],
        trim: true,
        maxlength: [60, 'Trip length cannot exceed 60 characters']
    },
    start: {
        type: Date,
        required: [true, 'Start date is required']
    },
    resort: {
        type: String,
        required: [true, 'Resort is required'],
        trim: true,
        maxlength: [120, 'Resort cannot exceed 120 characters']
    },
    perPerson: {
        type: Number,
        required: [true, 'Per-person price is required'],
        min: [0, 'Per-person price cannot be negative'],
        max: [1000000, 'Per-person price is unreasonably large']
    },
    image: {
        type: String,
        required: [true, 'Image filename is required'],
        trim: true,
        match: [/^[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/, 'Image must be a bare image filename']
    },
    description: {
        type: String,
        required: [true, 'Description is required'],
        trim: true,
        maxlength: [2000, 'Description cannot exceed 2000 characters']
    }
});

// Weighted full-text index: name matches count three times as much as
// description matches, mirroring Enhancement Two's application-level
// field weights so relevance rankings are comparable across engines.
tripSchema.index(
    { name: 'text', resort: 'text', description: 'text' },
    { weights: { name: 3, resort: 2, description: 1 }, name: 'trip_text_weighted' }
);

// Ascending index on perPerson — serves two things the aggregation
// engine now does: minPrice/maxPrice range filtering (a $match on this
// field can seek the index instead of scanning) and sortBy=price
// (an indexed field sorts without an in-memory sort stage). At this
// catalog's current size (dozens of trips) neither matters for actual
// latency; a collection scan is already sub-millisecond. The index
// earns its keep by being the correct shape for where this project is
// headed — a catalog that outgrows "just scan it" — rather than a
// premature optimization for data that doesn't exist yet.
tripSchema.index({ perPerson: 1 });

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
