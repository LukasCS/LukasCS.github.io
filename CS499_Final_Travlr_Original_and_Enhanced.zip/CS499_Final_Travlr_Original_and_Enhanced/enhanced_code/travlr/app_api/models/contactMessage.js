const mongoose = require('mongoose');

// Contact message schema — backs the customer site's Contact page
// (POST /api/contact). Follows the same validate-in-the-schema
// approach as travlr.js and user.js: required/trim/maxlength keep
// junk and oversized payloads out of the database, and the email
// match regex rejects the same class of malformed addresses the user
// schema does, so a bad "email" can never be stored and later used to
// reply to someone.
const contactMessageSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
        maxlength: [100, 'Name cannot exceed 100 characters']
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        trim: true,
        lowercase: true,
        maxlength: [200, 'Email cannot exceed 200 characters'],
        match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Email must be a valid address']
    },
    message: {
        type: String,
        required: [true, 'Message is required'],
        trim: true,
        maxlength: [2000, 'Message cannot exceed 2000 characters']
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const ContactMessage = mongoose.model('contactmessages', contactMessageSchema);
module.exports = ContactMessage;