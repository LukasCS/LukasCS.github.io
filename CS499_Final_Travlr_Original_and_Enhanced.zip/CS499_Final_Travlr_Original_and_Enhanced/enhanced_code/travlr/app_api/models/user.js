const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// User schema — CS 499 Enhancement Three (Databases).
//
// Adds the role field the code review flagged as missing: every user
// is 'user' by default and only explicit promotion (see
// scripts/promote-admin.js) grants 'admin'. The role is enforced by
// enum at the schema level, embedded in the JWT at login, and checked
// by the requireRole middleware on every mutating trip route.
// Registration NEVER reads a role from the request body, which closes
// the mass-assignment path to self-granted privileges.
const userSchema = new mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: [true, 'Email is required'],
        trim: true,
        lowercase: true,
        match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Email must be a valid address']
    },
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true,
        maxlength: [80, 'Name cannot exceed 80 characters']
    },
    role: {
        type: String,
        enum: ['user', 'admin'],
        default: 'user'
    },
    hash: String,
    salt: String
});

// Method to set the password on this record.
userSchema.methods.setPassword = function(password){
    this.salt = crypto.randomBytes(16).toString('hex');
    this.hash = crypto.pbkdf2Sync(password, this.salt,
        1000, 64, 'sha512').toString('hex');
};

// Method to compare entered password against stored hash
userSchema.methods.validPassword = function(password) {
    var hash = crypto.pbkdf2Sync(password,
        this.salt, 1000, 64, 'sha512').toString('hex');
    return this.hash === hash;
};

// Method to generate a JSON Web Token for the current record.
// The role claim lets the API authorize without a database round trip
// on every request; tokens expire after an hour, which bounds how
// long a stale role assignment can live.
userSchema.methods.generateJWT = function() {
    return jwt.sign(
        {
            _id: this._id,
            email: this.email,
            name: this.name,
            role: this.role || 'user'
        },
        process.env.JWT_SECRET,
        { expiresIn: '1h' });
};

const User = mongoose.model('users', userSchema);
module.exports = User;
