const mongoose = require('mongoose');

// Trip rating schema — lets a signed-in user rate a trip 1-5 stars.
//
// This is a DIFFERENT concept from the resort star class embedded in
// travlr.js's `resort` string (e.g. "Emerald Bay, 3 stars") and read
// by tripsDb.js's RATING_EXPR: that value is a property tier set by
// the catalog admin, unrelated to what any visitor thought of the
// trip. To keep the two from being confused anywhere in the code or
// the UI, this collection and its fields are named `tripRating` /
// `stars`, the API responses call the derived figure
// `communityRating`, and the React/HBS copy always says "Community
// rating" rather than a bare "Rating".
//
// The unique compound index on (tripCode, userEmail) below is the
// actual integrity mechanism for "exactly one rating per user per
// trip" — not a check in the controller. A check-then-write in
// application code has a race window under concurrent requests (two
// simultaneous first-time ratings from the same user could both see
// "no existing document" and both insert); the unique index makes a
// second document for the same pair impossible at the database layer
// regardless of request timing. The controller performs an upsert
// keyed on the same (tripCode, userEmail) pair, so the normal
// "rate again to change your mind" path updates the existing document
// and never touches that constraint.
const tripRatingSchema = new mongoose.Schema({
    tripCode: {
        type: String,
        required: [true, 'Trip code is required'],
        trim: true,
        uppercase: true,
        // Mirrors travlr.js's code format exactly, so a rating can
        // never reference a code shape the trip collection would reject.
        match: [/^[A-Z0-9]{4,12}$/, 'Trip code must be 4-12 uppercase letters or digits']
    },
    userEmail: {
        type: String,
        required: [true, 'User email is required'],
        trim: true,
        lowercase: true,
        match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Email must be a valid address']
    },
    stars: {
        type: Number,
        required: [true, 'Star rating is required'],
        min: [1, 'Rating cannot be below 1 star'],
        max: [5, 'Rating cannot exceed 5 stars'],
        validate: {
            validator: Number.isInteger,
            message: 'Rating must be a whole number of stars'
        }
    }
}, {
    // Adds createdAt/updatedAt automatically; updatedAt moves every
    // time an upsert changes an existing rater's stars, which is the
    // audit trail for "when did this user last change their mind".
    timestamps: true
});

tripRatingSchema.index({ tripCode: 1, userEmail: 1 }, { unique: true });

const TripRating = mongoose.model('tripratings', tripRatingSchema);
module.exports = TripRating;
