// Bring in the DB connection and the Trip schema
const Mongoose = require('./db');
const Trip = require('./travlr');

// Read seed data from json file
var fs = require('fs');
var trips = JSON.parse(fs.readFileSync('./data/trips.json','utf8'));

// delete any existing records, then insert seed data
const seedDB = async () => {
    // Drop the entire collection — documents AND indexes — instead of
    // only deleting documents. Enhancement Three changed index
    // definitions (the trip code index became unique, and a weighted
    // text index was added), and MongoDB refuses to create an index
    // whose name collides with an existing one built from an older
    // schema. Dropping first makes the seed a true migration: it
    // always leaves the collection exactly as the current schema
    // defines it, no matter what state the database was in.
    await Trip.collection.drop().catch((error) => {
        // A brand-new database has nothing to drop; that's fine.
        if (error.codeName !== 'NamespaceNotFound') {
            throw error;
        }
    });
    await Trip.insertMany(trips);
    // Build schema indexes (including the weighted text index that
    // powers database-side relevance search) as part of seeding.
    await Trip.createIndexes();
};

// Close the MongoDB connection and exit
seedDB().then(async () => {
    await Mongoose.connection.close();
    process.exit(0);
});