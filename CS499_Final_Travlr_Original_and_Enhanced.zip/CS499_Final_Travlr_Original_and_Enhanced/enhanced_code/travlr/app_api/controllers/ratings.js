const mongoose = require('mongoose');
require('../models/travlr');
require('../models/tripRating');
const Trip = mongoose.model('trips');
const TripRating = mongoose.model('tripratings');
const asyncHandler = require('../middleware/asyncHandler');
const { ApiError } = require('../middleware/errorHandler');

// Ratings controller — a signed-in user rates a trip 1-5 stars and can
// read back their own vote. NOT admin-gated: any authenticated user
// may rate any trip, so these routes use authenticateJWT alone (see
// routes/index.js), unlike the admin-only trip mutation routes.
//
// Naming note: everything here is the visitor-submitted "community
// rating", kept textually separate from the RESORT star class parsed
// out of the `resort` field by tripsDb.js's RATING_EXPR. See the
// file-level comment in models/tripRating.js for the full rationale.

const MIN_STARS = 1;
const MAX_STARS = 5;

// Defensive parsing: reject anything that is not a whole number in
// [1, 5], including strings, floats, and out-of-range integers.
function parseStars(value) {
    const stars = Number(value);
    if (!Number.isFinite(stars) || !Number.isInteger(stars) || stars < MIN_STARS || stars > MAX_STARS) {
        return null;
    }
    return stars;
}

// The one place community averages are computed: a single aggregation
// over tripratings, grouped by tripCode, with $avg and $sum doing the
// arithmetic inside MongoDB. $match narrows to just the requested
// codes first (a page of search results, or a single trip), so a
// listing page never scans every rating ever cast to summarize the
// six-to-fifty trips it is about to display.
//
// The return value is a Map so callers can merge it into trip objects
// with an O(1) lookup per trip — that merge is plain object assembly,
// not a computation, which is what keeps the "averages MUST be
// computed by the database, not in a JavaScript loop" rule intact
// even though the merge itself happens in application code.
async function getRatingSummaries(tripCodes) {
    const summaries = new Map();
    if (!Array.isArray(tripCodes) || tripCodes.length === 0) {
        return summaries;
    }
    const rows = await TripRating.aggregate([
        { $match: { tripCode: { $in: tripCodes } } },
        {
            $group: {
                _id: '$tripCode',
                average: { $avg: '$stars' },
                count: { $sum: 1 }
            }
        }
    ]).exec();
    for (const row of rows) {
        summaries.set(row._id, {
            average: Math.round(row.average * 10) / 10,
            count: row.count
        });
    }
    return summaries;
}

// Chosen approach for surfacing community averages on list responses:
// a single extra aggregation per request (getRatingSummaries above),
// merged into the already-fetched page. The alternative considered
// was a $lookup sub-pipeline bolted onto each query engine's own
// aggregation (tripsDb.js's runDbSearch) — rejected because it would
// need to be written and kept in sync TWICE (the db engine's
// aggregation pipeline and the app engine's in-memory array both
// produce trip lists, but the app engine has no pipeline to attach a
// $lookup to at all), whereas this approach runs once, after either
// engine has already produced its page, in the one shared place
// (tripsSearch in tripsQuery.js) both engines funnel through.
async function attachCommunityRatings(trips) {
    const codes = trips.map((trip) => trip.code);
    const summaries = await getRatingSummaries(codes);
    return trips.map((trip) => ({
        ...trip,
        communityRating: summaries.get(trip.code) || null
    }));
}

// POST /trips/:tripCode/rating — body { stars }. Upserts the caller's
// rating keyed on (tripCode, userEmail), so rating the same trip again
// updates the existing document instead of creating a second one; see
// models/tripRating.js for why the unique index, not this upsert, is
// the actual integrity guarantee.
const rateTrip = asyncHandler(async (req, res) => {
    const tripCode = req.params.tripCode.toUpperCase();
    const stars = parseStars(req.body.stars);
    if (stars === null) {
        throw new ApiError(400, `stars must be an integer between ${MIN_STARS} and ${MAX_STARS}`);
    }

    const trip = await Trip.findOne({ code: tripCode }).lean().exec();
    if (!trip) {
        throw new ApiError(404, `Trip '${tripCode}' not found`);
    }

    // req.auth is the decoded JWT payload attached by authenticateJWT.
    const userEmail = req.auth.email;
    await TripRating.findOneAndUpdate(
        { tripCode, userEmail },
        { tripCode, userEmail, stars },
        // returnDocument: 'after' asks for the saved version rather than
        // the version from before the write. It replaces the older
        // `new: true` spelling, which Mongoose now prints a deprecation
        // notice for on every call.
        { upsert: true, returnDocument: 'after', setDefaultsOnInsert: true, runValidators: true }
    ).exec();

    const summaries = await getRatingSummaries([tripCode]);
    const communityRating = summaries.get(tripCode) || { average: 0, count: 0 };
    return res.status(200).json({ tripCode, stars, communityRating });
});

// GET /trips/:tripCode/rating — the caller's own rating for a trip, or
// null when they have not rated it yet. Still JWT-protected even
// though it is read-only: "your own rating" has no meaning for an
// anonymous caller.
const getMyRating = asyncHandler(async (req, res) => {
    const tripCode = req.params.tripCode.toUpperCase();
    const trip = await Trip.findOne({ code: tripCode }).lean().exec();
    if (!trip) {
        throw new ApiError(404, `Trip '${tripCode}' not found`);
    }

    const rating = await TripRating.findOne({ tripCode, userEmail: req.auth.email }).lean().exec();
    return res.status(200).json({ stars: rating ? rating.stars : null });
});

module.exports = { rateTrip, getMyRating, getRatingSummaries, attachCommunityRatings };
