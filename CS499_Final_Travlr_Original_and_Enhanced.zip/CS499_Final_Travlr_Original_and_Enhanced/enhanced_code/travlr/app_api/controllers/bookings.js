const BookingRequest = require('../models/bookingRequest');
const Trip = require('../models/travlr');
const asyncHandler = require('../middleware/asyncHandler');
const { ApiError } = require('../middleware/errorHandler');

// Booking controller for the customer site's "Book this trip" form.
// Public and unauthenticated by design, the same as contact.js:
// visitors browsing the catalog do not have accounts, and requiring
// one before someone can ask about a trip would lose the enquiry.
//
// Shape follows contact.js: a cheap type/emptiness check first so an
// obviously-missing field fails with a message naming what is missing,
// then Mongoose schema validation as the authoritative check, with any
// ValidationError translated to a 400 by the centralized error handler.

// POST: /bookings - stores a visitor's booking request for one trip
const createBooking = asyncHandler(async (req, res) => {
    const { tripCode, name, email, notes } = req.body;

    if (typeof tripCode !== 'string' || typeof name !== 'string' ||
        typeof email !== 'string' ||
        !tripCode.trim() || !name.trim() || !email.trim()) {
        throw new ApiError(400, 'Trip, name, and email are all required');
    }

    // travellers arrives as a string from an HTML form and as a number
    // from a JSON client, so it is normalized here before the schema's
    // min/max validators see it. Number('') is 0 and Number('two') is
    // NaN; both fail the check below with a message a visitor can act
    // on, rather than reaching the database as a cast error.
    const travellers = Number(req.body.travellers);
    if (!Number.isInteger(travellers)) {
        throw new ApiError(400, 'Number of travellers must be a whole number');
    }

    // The trip is looked up rather than trusted from the form, for two
    // reasons: a request naming a trip that does not exist is rejected
    // instead of stored, and the trip name saved on the record is the
    // catalog's own name rather than whatever the submitted page said.
    const trip = await Trip.findOne({ code: tripCode.trim().toUpperCase() }).lean();
    if (!trip) {
        throw new ApiError(404, 'That trip is no longer in the catalog');
    }

    const saved = await new BookingRequest({
        tripCode: trip.code,
        tripName: trip.name,
        name,
        email,
        travellers,
        notes: typeof notes === 'string' ? notes : ''
    }).save();

    return res.status(201).json(saved);
});

module.exports = {
    createBooking
};
