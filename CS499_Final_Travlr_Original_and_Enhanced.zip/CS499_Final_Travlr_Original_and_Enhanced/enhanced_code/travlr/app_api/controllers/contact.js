const mongoose = require('mongoose');
const ContactMessage = require('../models/contactMessage'); // Register model
const Model = mongoose.model('contactmessages');
const asyncHandler = require('../middleware/asyncHandler');
const { ApiError } = require('../middleware/errorHandler');

// Contact controller for the customer site's Contact page. Public and
// unauthenticated by design — visitors don't have accounts. Follows
// the same shape as trips.js: a cheap type/emptiness check up front so
// an obviously-missing field fails with a clear message, then Mongoose
// schema validation (required/maxlength/email format) as the
// authoritative check, with any resulting ValidationError translated
// to a 400 by the centralized error handler.

// POST: /contact - stores a visitor's contact message
const createMessage = asyncHandler(async (req, res) => {
    const { name, email, message } = req.body;
    if (typeof name !== 'string' || typeof email !== 'string' || typeof message !== 'string' ||
        !name.trim() || !email.trim() || !message.trim()) {
        throw new ApiError(400, 'Name, email, and message are all required');
    }

    const saved = await new ContactMessage({ name, email, message }).save();
    return res.status(201).json(saved);
});

module.exports = {
    createMessage
};