// Search / sort / pagination / recommendation controllers.
// CS 499 Enhancement Two: Algorithms and Data Structures.
//
// Enhancement Two implemented these in application code (merge sort,
// scoring, heap selection) to demonstrate the algorithms explicitly.
// Enhancement Three added a database engine (see tripsDb.js) that
// fulfills the same contract with MongoDB aggregation pipelines and a
// weighted text index. The ?engine= parameter selects between them
// (db is the default; app retains the Enhancement Two implementation
// for the documented head-to-head comparison), and both engines share
// the same cursor format and response shape.
const mongoose = require('mongoose');
require('../models/travlr');
const Model = mongoose.model('trips');
const asyncHandler = require('../middleware/asyncHandler');
const { ApiError } = require('../middleware/errorHandler');
const mergeSort = require('../algorithms/mergeSort');
const BoundedMinHeap = require('../algorithms/minHeap');
const { tokenize, scoreTripAgainstQuery, similarityScore, buildIdf, parsePrice, parseStars, FIELD_WEIGHTS } = require('../algorithms/relevance');
const { encodeCursor, decodeCursor } = require('../algorithms/cursor');
const Trie = require('../algorithms/trie');
const dbEngine = require('./tripsDb');
const { attachCommunityRatings } = require('./ratings');

const DEFAULT_LIMIT = 6;
const MAX_LIMIT = 50;
const SORT_FIELDS = new Set(['name', 'price', 'start', 'relevance']);

// ---- Autocomplete suggestions (trie) ----
const SUGGEST_DEFAULT_LIMIT = 5;
const SUGGEST_MAX_LIMIT = 10;
const SUGGEST_MIN_QUERY_LENGTH = 2;

// Extracts the value a trip is sorted by for a given field.
function sortValueOf(trip, sortBy, scores) {
    switch (sortBy) {
        case 'price': {
            const price = parsePrice(trip.perPerson);
            return price === null ? Number.MAX_SAFE_INTEGER : price;
        }
        case 'start':
            return trip.start ? new Date(trip.start).getTime() : 0;
        case 'relevance':
            return scores.get(trip.code) || 0;
        default:
            return (trip.name || '').toLowerCase();
    }
}

function compareValues(a, b) {
    if (a < b) return -1;
    if (a > b) return 1;
    return 0;
}

// GET /trips/search?search=&sortBy=&order=&limit=&cursor=&engine=db|app
//                   &minPrice=&maxPrice=&rating=
const tripsSearch = asyncHandler(async (req, res) => {
    // Engine selection (Enhancement Three): default to the database
    // engine; ?engine=app runs the Enhancement Two application engine.
    const engine = req.query.engine === 'app' ? 'app' : 'db';
    if (engine === 'db') {
        const params = dbEngine.parseCommonParams(req);
        const payload = await dbEngine.runDbSearch({ ...params, cursor: req.query.cursor });
        // Community ratings (a DIFFERENT concept from the resort star
        // class embedded in `resort`) are merged in here rather than
        // inside runDbSearch's own aggregation pipeline: this is the one
        // place both engines' result pages pass through, so the merge
        // logic exists once instead of being duplicated per engine. See
        // ratings.js's attachCommunityRatings for why a second
        // aggregation, not a pipeline $lookup, was chosen.
        const results = await attachCommunityRatings(payload.results);
        return res.status(200).json({ ...payload, results, engine: 'db' });
    }

    // ---- Application engine (Enhancement Two) ----
    // ---- Parse and clamp inputs defensively ----
    const query = typeof req.query.search === 'string' ? req.query.search.trim() : '';
    const queryTokens = tokenize(query);

    let sortBy = typeof req.query.sortBy === 'string' ? req.query.sortBy : '';
    if (sortBy && !SORT_FIELDS.has(sortBy)) {
        throw new ApiError(400, `Unsupported sortBy value: must be one of ${[...SORT_FIELDS].join(', ')}`);
    }
    if (!sortBy) {
        sortBy = queryTokens.length > 0 ? 'relevance' : 'name';
    }

    const order = req.query.order === 'desc' ? 'desc' : 'asc';
    let limit = Number.parseInt(req.query.limit, 10);
    if (!Number.isInteger(limit)) {
        limit = DEFAULT_LIMIT;
    }
    limit = Math.max(1, Math.min(MAX_LIMIT, limit));

    // Price/rating filters share their validation rules with the
    // database engine (see dbEngine.parseFilterParams in tripsDb.js) so
    // the two engines never drift apart on what counts as a valid
    // range or an in-bounds rating floor.
    const { minPrice, maxPrice, rating } = dbEngine.parseFilterParams(req);

    // ---- Load, filter by relevance, sort with merge sort ----
    const allTrips = (await Model.find({}).lean().exec());

    const scores = new Map(); // code -> relevance score (O(1) lookups)
    let matched = allTrips;
    if (queryTokens.length > 0) {
        matched = allTrips.filter((trip) => {
            const score = scoreTripAgainstQuery(trip, queryTokens);
            scores.set(trip.code, score);
            return score > 0;
        });
    }

    // Price range: perPerson is a Number at the schema level, but
    // parsePrice is used anyway for symmetry with the rest of this
    // file's defensive treatment of that field.
    if (minPrice !== null) {
        matched = matched.filter((trip) => {
            const price = parsePrice(trip.perPerson);
            return price !== null && price >= minPrice;
        });
    }
    if (maxPrice !== null) {
        matched = matched.filter((trip) => {
            const price = parsePrice(trip.perPerson);
            return price !== null && price <= maxPrice;
        });
    }

    // Rating floor: a trip with no parseable star rating in its resort
    // string is excluded whenever this filter is active, matching the
    // database engine's rule (see the runDbSearch doc comment).
    if (rating !== null) {
        matched = matched.filter((trip) => {
            const stars = parseStars(trip.resort);
            return stars !== null && stars >= rating;
        });
    }

    const direction = order === 'desc' ? -1 : 1;
    // For relevance, "asc" makes no sense; best matches always first.
    const relevanceDirection = sortBy === 'relevance' ? -1 : direction;
    const sorted = mergeSort(matched, (a, b) => {
        const primary = compareValues(
            sortValueOf(a, sortBy, scores),
            sortValueOf(b, sortBy, scores)
        ) * (sortBy === 'relevance' ? relevanceDirection : direction);
        if (primary !== 0) {
            return primary;
        }
        // Unique tiebreaker keeps pagination deterministic.
        return compareValues(a.code, b.code);
    });

    // ---- Cursor pagination ----
    const context = { sortBy, order, query };
    let startIndex = 0;
    if (req.query.cursor) {
        const position = decodeCursor(req.query.cursor, context);
        const resumeAfter = sorted.findIndex((trip) =>
            sortValueOf(trip, sortBy, scores) === position.value &&
            trip.code === position.code);
        // If the anchor record was deleted between pages, fall back to
        // the first record PAST its sort position instead of failing.
        startIndex = resumeAfter >= 0
            ? resumeAfter + 1
            : sorted.findIndex((trip) => {
                const cmp = compareValues(sortValueOf(trip, sortBy, scores), position.value);
                return (sortBy === 'relevance' ? -cmp : cmp * direction) > 0;
            });
        if (startIndex < 0) {
            startIndex = sorted.length;
        }
    }

    const page = sorted.slice(startIndex, startIndex + limit);
    const hasMore = startIndex + limit < sorted.length;
    const nextCursor = hasMore
        ? encodeCursor(context, {
            sortValue: sortValueOf(page[page.length - 1], sortBy, scores),
            code: page[page.length - 1].code
        })
        : null;

    // Same merge as the db engine branch above, applied to the app
    // engine's in-memory page — one shared code path for both engines.
    const resultsWithRatings = await attachCommunityRatings(page);

    return res.status(200).json({
        results: resultsWithRatings,
        totalMatches: sorted.length,
        nextCursor,
        sortBy,
        order,
        engine: 'app'
    });
});

// GET /trips/recommendations?basedOn=CODE&k=3
const tripsRecommendations = asyncHandler(async (req, res) => {
    const basedOn = typeof req.query.basedOn === 'string' ? req.query.basedOn.trim() : '';
    if (!basedOn) {
        throw new ApiError(400, 'basedOn query parameter is required');
    }
    let k = Number.parseInt(req.query.k, 10);
    if (!Number.isInteger(k)) {
        k = 3;
    }
    k = Math.max(1, Math.min(10, k));

    const allTrips = await Model.find({}).lean().exec();

    // Hash map index: O(n) to build once, O(1) to look up the seed —
    // and reusable for any number of subsequent lookups per request.
    const byCode = new Map(allTrips.map((trip) => [trip.code, trip]));
    const seed = byCode.get(basedOn);
    if (!seed) {
        throw new ApiError(404, `Trip '${basedOn}' not found`);
    }

    // IDF weights are computed once per request over the collection
    // (O(n) in total tokens), so rare destination vocabulary dominates
    // the similarity score. Then a single O(n log k) pass with a
    // bounded min-heap of size k selects the recommendations.
    const idf = buildIdf(allTrips);
    const scored = new Map();
    const heap = new BoundedMinHeap(k, (trip) => scored.get(trip.code));
    for (const candidate of allTrips) {
        if (candidate.code === seed.code) {
            continue;
        }
        scored.set(candidate.code, similarityScore(seed, candidate, idf));
        heap.offer(candidate);
    }

    const recommendations = heap.drainDescending().map((trip) => ({
        ...trip,
        similarity: Number(scored.get(trip.code).toFixed(3))
    }));

    return res.status(200).json({ basedOn: seed.code, recommendations });
});

// GET /trips/stats — catalog analytics via aggregation pipeline.
const tripsStats = asyncHandler(async (req, res) => {
    const stats = await dbEngine.runCatalogStats();
    return res.status(200).json(stats);
});

// GET /trips/suggest?q=<prefix>&limit= — autocomplete for the search box.
//
// The trie is built fresh from the current catalog on every request
// rather than cached. At this project's scale (dozens of trips, a few
// hundred distinct tokens) that build is O(total tokens) — a handful
// of milliseconds — which is cheaper than it sounds and, more
// importantly, cheaper than the alternative: a cached trie needs an
// invalidation strategy (rebuild on every trip create/update/delete,
// or accept staleness) and that complexity buys nothing at this
// catalog size. The trade-off is deliberate and would be revisited if
// the catalog grew into the tens of thousands of trips, at which point
// the trie would move alongside the aggregation pipeline in tripsDb.js
// and be rebuilt incrementally instead of per request.
const tripsSuggest = asyncHandler(async (req, res) => {
    const rawQuery = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';

    let limit = Number.parseInt(req.query.limit, 10);
    if (!Number.isInteger(limit)) {
        limit = SUGGEST_DEFAULT_LIMIT;
    }
    limit = Math.max(1, Math.min(SUGGEST_MAX_LIMIT, limit));

    // Below the minimum length, a prefix matches too much of the
    // vocabulary to be a useful suggestion set — return early instead
    // of doing any trie work at all.
    if (rawQuery.length < SUGGEST_MIN_QUERY_LENGTH) {
        return res.status(200).json({ suggestions: [] });
    }

    const allTrips = await Model.find({}).lean().exec();

    const trie = new Trie();
    for (const trip of allTrips) {
        for (const token of tokenize(trip.name)) {
            trie.insert(token, FIELD_WEIGHTS.name);
        }
        for (const token of tokenize(trip.resort)) {
            trie.insert(token, FIELD_WEIGHTS.resort);
        }
        for (const token of tokenize(trip.description)) {
            trie.insert(token, FIELD_WEIGHTS.description);
        }
    }

    // The query itself is tokenized (never matched with a raw
    // user-supplied regex) and only its FIRST token drives the prefix
    // lookup — autocomplete completes the word being typed right now,
    // not every word in a multi-word query.
    const queryTokens = tokenize(rawQuery);
    const prefix = queryTokens[0] || '';
    const suggestions = prefix ? trie.suggest(prefix, limit) : [];

    return res.status(200).json({ suggestions });
});

module.exports = { tripsSearch, tripsRecommendations, tripsStats, tripsSuggest };
