const mongoose = require('mongoose');
const User = require('../models/user');
const passport = require('passport');
const asyncHandler = require('../middleware/asyncHandler');
const { ApiError } = require('../middleware/errorHandler');

// Authentication controllers — hardened for CS 499 Enhancement Three.
//
// Defense in depth against NoSQL operator injection: the sanitize
// middleware has already stripped '$'-prefixed keys, and these
// handlers additionally require the credential fields to be plain
// strings. An attacker who somehow delivered {"email": {"gt": ""}}
// past the sanitizer would still be rejected here, because an object
// is not a string. Registration also never reads a role from the
// request body — roles are granted only by explicit promotion.
function requireStringFields(body, fields) {
    for (const field of fields) {
        if (typeof body[field] !== 'string' || body[field].length === 0) {
            throw new ApiError(400, 'All fields are required and must be text values');
        }
    }
}

const register = asyncHandler(async (req, res) => {
    requireStringFields(req.body, ['name', 'email', 'password']);

    const user = new User({
        name: req.body.name,
        email: req.body.email
        // role intentionally NOT taken from the request body:
        // the schema default assigns 'user'.
    });
    user.setPassword(req.body.password);
    // A duplicate email raises a Mongo E11000 error and a malformed
    // email raises a ValidationError; both are translated to client
    // errors by the centralized error handler.
    try {
        await user.save();
    } catch (error) {
        if (error && error.code === 11000) {
            throw new ApiError(409, 'An account with that email already exists');
        }
        throw error;
    }
    const token = user.generateJWT();
    return res.status(201).json({ token });
});

const login = (req, res, next) => {
    try {
        requireStringFields(req.body, ['email', 'password']);
    } catch (error) {
        return next(error);
    }
    // Delegate credential verification to the passport local strategy.
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return next(err);
        }
        if (user) {
            const token = user.generateJWT();
            return res.status(200).json({ token });
        }
        return res.status(401).json(info);
    })(req, res, next);
};

module.exports = {
    register,
    login
};
