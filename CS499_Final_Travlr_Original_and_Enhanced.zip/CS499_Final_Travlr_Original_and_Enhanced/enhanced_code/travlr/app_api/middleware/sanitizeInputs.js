// NoSQL-injection input sanitization — CS 499 Enhancement Three.
//
// MongoDB operator injection works by smuggling keys that begin with
// a dollar sign (or contain a dot) into objects that reach a query,
// e.g. POSTing {"email": {"$gt": ""}, "password": {"$gt": ""}} to a
// naive login handler turns an equality check into "match any user".
// This middleware walks every inbound container (body, query, route
// params) and strips any key starting with '$' or containing '.',
// so operator syntax can never travel from the network into a query
// object. Values are left untouched — a description that merely
// mentions "$100" is data, not an operator, because injection
// requires the dollar sign in the KEY position.
//
// Complexity: O(total keys) per request, no regular expressions, no
// recursion depth risk beyond the payload's own nesting (bounded by
// Express's JSON body size limit).

function sanitizeValue(value) {
    if (Array.isArray(value)) {
        return value.map(sanitizeValue);
    }
    if (value !== null && typeof value === 'object') {
        const clean = {};
        for (const key of Object.keys(value)) {
            if (key.startsWith('$') || key.includes('.')) {
                continue; // drop operator-shaped keys entirely
            }
            clean[key] = sanitizeValue(value[key]);
        }
        return clean;
    }
    return value;
}

function sanitizeInputs(req, res, next) {
    if (req.body && typeof req.body === 'object') {
        req.body = sanitizeValue(req.body);
    }
    if (req.params && typeof req.params === 'object') {
        req.params = sanitizeValue(req.params);
    }
    // req.query is a getter in some Express versions; mutate in place.
    if (req.query && typeof req.query === 'object') {
        for (const key of Object.keys(req.query)) {
            if (key.startsWith('$') || key.includes('.')) {
                delete req.query[key];
            } else {
                req.query[key] = sanitizeValue(req.query[key]);
            }
        }
    }
    next();
}

module.exports = sanitizeInputs;
