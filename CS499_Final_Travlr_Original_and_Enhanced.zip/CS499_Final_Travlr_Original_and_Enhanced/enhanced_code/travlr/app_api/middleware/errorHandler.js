// Centralized error-handling middleware for the /api routes.
//
// The original app.js had a partial handler that only recognized
// UnauthorizedError and, for every other error, neither responded nor
// called next() — leaving API requests to hang. This middleware
// guarantees every API error produces a JSON response with an
// appropriate status code, and never leaks stack traces to clients
// outside development.

// Custom error type controllers can throw to set a specific status.
class ApiError extends Error {
    constructor(statusCode, message) {
        super(message);
        this.statusCode = statusCode;
        this.name = 'ApiError';
    }
}

// 404 for unknown /api paths, forwarded into the error handler below.
const notFoundHandler = (req, res, next) => {
    next(new ApiError(404, `Not found: ${req.method} ${req.originalUrl}`));
};

// Express identifies error middleware by its four-parameter signature.
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
    let statusCode = err.statusCode || 500;
    let message = err.message || 'Internal Server Error';

    // JWT middleware (express-jwt style) errors
    if (err.name === 'UnauthorizedError') {
        statusCode = 401;
        message = err.name + ': ' + err.message;
    }

    // Mongoose validation failures are client errors, not server faults.
    // Its combined message names the model and repeats each field path
    // ("bookingrequests validation failed: email: Email must be a valid
    // address"), which reads as database internals on a customer-facing
    // page. The individual field messages are written for a reader, so
    // the first one is sent instead; the rest stay available in the log.
    if (err.name === 'ValidationError') {
        statusCode = 400;
        const firstField = Object.values(err.errors || {})[0];
        if (firstField && firstField.message) {
            message = firstField.message;
        }
    }

    // Malformed ObjectId or similar cast problems
    if (err.name === 'CastError') {
        statusCode = 400;
        message = 'Malformed request parameter';
    }

    // MongoDB reports a violated unique index as error code 11000. That
    // is the caller sending a value that is already taken (a trip code,
    // for example), not a fault in this server, so it answers 409
    // Conflict. Without this branch the error fell through to the 500
    // case below, which both mislabeled the problem and printed a full
    // stack trace to the server log for what is a routine rejection.
    if (err.code === 11000) {
        statusCode = 409;
        const field = Object.keys(err.keyValue || {})[0];
        message = field
            ? `A record with that ${field} already exists`
            : 'A record with that value already exists';
    }

    if (statusCode === 500) {
        // Log unexpected errors server side; clients get a generic message.
        console.error(err);
        if (process.env.NODE_ENV !== 'development') {
            message = 'Internal Server Error';
        }
    }

    return res.status(statusCode).json({ message });
};

module.exports = { ApiError, notFoundHandler, errorHandler };
