// Role-based access control — CS 499 Enhancement Three.
//
// Runs AFTER authenticateJWT, which has already verified the token
// signature and attached the decoded payload to req.auth. Tokens
// issued before the role field existed carry no role claim and are
// treated as ordinary users, so legacy sessions degrade safely
// instead of failing open.
function requireRole(requiredRole) {
    return function (req, res, next) {
        const role = (req.auth && req.auth.role) || 'user';
        if (role !== requiredRole) {
            return res.status(403).json({
                message: `This operation requires the '${requiredRole}' role`
            });
        }
        return next();
    };
}

module.exports = requireRole;
