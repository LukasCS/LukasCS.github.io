// Prefix tree (trie) for catalog autocomplete — CS 499 Enhancement Two.
//
// Why a trie instead of scanning every token per keystroke: a linear
// scan re-tokenizes and re-checks every field of every trip on every
// keystroke, which is O(catalog size) work repeated for each character
// the admin types. A trie pays that cost once, at build time, and
// turns every subsequent keystroke into a walk bounded by the prefix
// itself — the catalog's total size drops out of the per-keystroke
// cost entirely. That trade (build once, query cheaply many times) is
// the same rationale as buildIdf() in relevance.js, just applied to
// character prefixes instead of token document frequency.
//
// Complexity:
//   - insert(token, weight): O(L) where L is the token length — one
//     hop per character, creating nodes only where the path does not
//     already exist.
//   - suggest(prefix, k): O(P + S) where P is the prefix length (the
//     walk down to the prefix's node) and S is the size of the subtree
//     under that node (the walk that collects every completed token
//     beneath it). Ranking the collected candidates is an additional
//     O(m log m) over m = S matches, which is negligible next to the
//     catalog-wide alternative of O(n) per keystroke.
//
// The subtree walk uses an EXPLICIT STACK rather than recursion.
// Recursive DFS ties call-stack depth to the longest token in the
// catalog; an explicit stack keeps that depth data, not control flow,
// so a pathologically long token cannot exhaust the JS call stack
// (the same "no recursion-depth risk" reasoning documented for
// mergeSort would not apply here, since sort recursion depth is
// bounded by log n — token length is not bounded the same way).
//
// Security note: tokens and prefixes are validated character-by-character
// against a fixed lowercase-alphanumeric alphabet (no regular expression
// is compiled from user input, matching the no-ReDoS rule in
// relevance.js). A token or prefix containing any other character is
// rejected outright rather than partially consumed.

const ALPHABET_MIN = 'a'.charCodeAt(0);
const ALPHABET_MAX = 'z'.charCodeAt(0);
const DIGIT_MIN = '0'.charCodeAt(0);
const DIGIT_MAX = '9'.charCodeAt(0);

// Character-class check written as arithmetic, not a regex — there is
// nothing here to catastrophically backtrack, but staying consistent
// with "no regex over untrusted input" keeps the security story simple.
function isLowerAlphanumeric(char) {
    const code = char.charCodeAt(0);
    return (code >= ALPHABET_MIN && code <= ALPHABET_MAX) ||
        (code >= DIGIT_MIN && code <= DIGIT_MAX);
}

function isValidToken(token) {
    if (typeof token !== 'string' || token.length === 0) {
        return false;
    }
    for (let i = 0; i < token.length; i += 1) {
        if (!isLowerAlphanumeric(token[i])) {
            return false;
        }
    }
    return true;
}

class TrieNode {
    constructor() {
        // Map, not a plain object, so keys can never collide with
        // inherited Object.prototype properties (e.g. a token that
        // happened to be "constructor").
        this.children = new Map();
        this.isWord = false;
        // Accumulated across every insert of this exact token, so a
        // word that shows up in many trips' names (or in a trip's
        // name AND its description) naturally outranks one that
        // appears once — the same "more evidence, higher score" idea
        // as scoreTripAgainstQuery, just pre-aggregated at build time.
        this.weight = 0;
    }
}

class Trie {
    constructor() {
        this.root = new TrieNode();
    }

    /**
     * Inserts a token with a weight contribution. Safe to call more
     * than once for the same token (e.g. once per trip, once per
     * field) — weights accumulate rather than overwrite.
     * Invalid input (not a non-empty lowercase-alphanumeric string) is
     * silently ignored: building the vocabulary from hundreds of trip
     * records should not abort because one description contained an
     * odd token, and the caller already tokenizes with relevance.js's
     * tokenize(), which guarantees this alphabet.
     * @param {string} token
     * @param {number} weight
     */
    insert(token, weight) {
        if (!isValidToken(token) || typeof weight !== 'number' || !Number.isFinite(weight)) {
            return;
        }
        let node = this.root;
        for (let i = 0; i < token.length; i += 1) {
            const char = token[i];
            let next = node.children.get(char);
            if (!next) {
                next = new TrieNode();
                node.children.set(char, next);
            }
            node = next;
        }
        node.isWord = true;
        node.weight += weight;
    }

    /**
     * Returns up to `limit` completed tokens that start with `prefix`,
     * ranked by accumulated weight (descending) and then alphabetically
     * (ascending) to break ties deterministically.
     *
     * Edge cases handled explicitly:
     *   - empty (or whitespace-only) prefix returns [] — walking from
     *     the root would collect the ENTIRE vocabulary, which is never
     *     what a two-character-minimum autocomplete box wants.
     *   - a prefix containing anything outside [a-z0-9] cannot exist in
     *     the trie (every edge is one of those characters), so it
     *     returns [] rather than throwing.
     *   - a prefix longer than any stored token simply runs off the
     *     end of the trie during the descent and returns [].
     * @param {string} prefix
     * @param {number} limit
     * @returns {string[]}
     */
    suggest(prefix, limit) {
        if (typeof prefix !== 'string' || prefix.length === 0) {
            return [];
        }
        const k = Number.isInteger(limit) && limit > 0 ? limit : 5;

        // ---- Descend to the prefix's node: O(prefix length) ----
        let node = this.root;
        for (let i = 0; i < prefix.length; i += 1) {
            const char = prefix[i];
            if (!isLowerAlphanumeric(char)) {
                return [];
            }
            const next = node.children.get(char);
            if (!next) {
                return [];
            }
            node = next;
        }

        // ---- Collect every completed word in the subtree: O(subtree size) ----
        // Explicit stack of [node, wordSoFar] pairs — see the file
        // header for why this is not a recursive walk.
        const matches = [];
        const stack = [[node, prefix]];
        while (stack.length > 0) {
            const [current, word] = stack.pop();
            if (current.isWord) {
                matches.push({ word, weight: current.weight });
            }
            for (const [char, child] of current.children) {
                stack.push([child, word + char]);
            }
        }

        matches.sort((a, b) => {
            if (b.weight !== a.weight) {
                return b.weight - a.weight;
            }
            return a.word < b.word ? -1 : a.word > b.word ? 1 : 0;
        });

        return matches.slice(0, k).map((match) => match.word);
    }
}

module.exports = Trie;
