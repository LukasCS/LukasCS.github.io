const express = require('express');
const router = express.Router();

// Controllers and middleware. authenticateJWT was extracted from this
// file into app_api/middleware for separation of concerns; the
// centralized error handlers guarantee JSON responses for all /api
// failures.
const tripsController = require('../controllers/trips');
const tripsQueryController = require('../controllers/tripsQuery');
const ratingsController = require('../controllers/ratings');
const authController = require('../controllers/authentication');
const contactController = require('../controllers/contact');
const bookingsController = require('../controllers/bookings');
const authenticateJWT = require('../middleware/authenticateJWT');
const requireRole = require('../middleware/requireRole');
const requireAdmin = [authenticateJWT, requireRole('admin')];
const { notFoundHandler, errorHandler } = require('../middleware/errorHandler');

// define route for our trips endpoint
router
    .route('/trips')
    .get(tripsController.tripsList)                        // GET is public
    .post(requireAdmin, tripsController.tripsAddTrip);     // POST requires admin role

// Enhancement Two (algorithms and data structures) endpoints. These
// MUST be registered before /trips/:tripCode, or Express would match
// "search" and "recommendations" as trip codes.
router
    .route('/trips/search')
    .get(tripsQueryController.tripsSearch);           // public, read-only

router
    .route('/trips/recommendations')
    .get(tripsQueryController.tripsRecommendations);  // public, read-only

// Enhancement Three: catalog analytics via aggregation pipeline.
router
    .route('/trips/stats')
    .get(tripsQueryController.tripsStats);            // public, read-only

// Autocomplete suggestions (trie-backed). Same ordering requirement as
// search/recommendations/stats above: this MUST be registered before
// /trips/:tripCode, or Express would match "suggest" as a trip code.
router
    .route('/trips/suggest')
    .get(tripsQueryController.tripsSuggest);          // public, read-only

// Trip ratings: any signed-in user (not admin-only), so this uses
// authenticateJWT alone rather than the requireAdmin pair. Registered
// before /trips/:tripCode for consistency with the other /trips/*
// subroutes above — Express would not actually confuse the two
// (:tripCode never matches a path with an extra /rating segment), but
// keeping every literal subroute ahead of the parameterized one avoids
// the reader having to reason about that each time a route is added.
router
    .route('/trips/:tripCode/rating')
    .get(authenticateJWT, ratingsController.getMyRating)    // caller's own rating
    .post(authenticateJWT, ratingsController.rateTrip);     // set/update caller's rating

// GET, PUT, DELETE routes for trips/:tripCode - requires parameter
// Code review finding: DELETE previously had no authentication, so any
// anonymous client could remove records. It is now JWT protected like
// the other mutating routes.
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)                          // GET is public
    .put(requireAdmin, tripsController.tripsUpdateTrip)            // PUT requires admin role
    .delete(requireAdmin, tripsController.tripsDeleteTrip);        // DELETE requires admin role

// define route for login endpoint
router
    .route('/login')
    .post(authController.login);

// define route for register endpoint
router
    .route('/register')
    .post(authController.register);

// define route for the customer site's Contact page - public, no auth
router
    .route('/contact')
    .post(contactController.createMessage);

// define route for the customer site's "Book this trip" form - public,
// no auth, same reasoning as /contact above: visitors browsing the
// catalog do not have accounts.
router
    .route('/bookings')
    .post(bookingsController.createBooking);

// Unknown /api paths return JSON 404s; all errors thrown or forwarded
// from the routes above converge on the centralized error handler.
router.use(notFoundHandler);
router.use(errorHandler);

module.exports = router;
