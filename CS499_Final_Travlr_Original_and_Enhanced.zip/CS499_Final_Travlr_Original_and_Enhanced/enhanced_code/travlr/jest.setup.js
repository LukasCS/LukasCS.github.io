// Loaded by Jest before any test file (see the "jest" block in
// package.json).
//
// The integration tests run against an in-memory MongoDB, and the
// mongodb-memory-server package downloads the MongoDB server
// executable it needs. By default it stores that executable inside
// this project's node_modules/.cache folder. On Windows that default
// breaks in deeply nested folders: the executable's full path can pass
// the operating system's 260-character path limit, and Windows then
// refuses to start it with a "file not found" error even though the
// file exists. Storing the executable in the system temporary folder
// instead keeps its path short no matter where this project sits, so
// the tests work from any extraction location. The environment
// variable is only set if the person running the tests has not chosen
// a location of their own.
const os = require('os');
const path = require('path');

if (!process.env.MONGOMS_DOWNLOAD_DIR) {
    process.env.MONGOMS_DOWNLOAD_DIR = path.join(
        os.tmpdir(),
        'mongodb-memory-server-binaries'
    );
}
