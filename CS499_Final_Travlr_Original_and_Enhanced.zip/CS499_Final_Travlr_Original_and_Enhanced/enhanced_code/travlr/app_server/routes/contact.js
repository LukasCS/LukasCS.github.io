var express = require('express');
var router = express.Router();
var controller = require('../controllers/contact');

/* GET contact page. */
router.get('/', controller.showForm);

/* POST contact form submission. */
router.post('/', controller.submitForm);

module.exports = router;