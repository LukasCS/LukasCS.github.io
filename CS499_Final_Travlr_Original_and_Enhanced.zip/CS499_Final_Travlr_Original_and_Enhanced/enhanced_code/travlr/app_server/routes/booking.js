var express = require('express');
var router = express.Router();
var controller = require('../controllers/booking');

/* POST a booking request submitted from a trip on the Travel page.
   There is no GET here on purpose: the form lives on /travel, so a
   visitor who opens /booking directly is sent back to the catalog
   rather than shown an empty form with no trip attached. */
router.post('/', controller.submitBooking);
router.get('/', (req, res) => res.redirect('/travel'));

module.exports = router;
