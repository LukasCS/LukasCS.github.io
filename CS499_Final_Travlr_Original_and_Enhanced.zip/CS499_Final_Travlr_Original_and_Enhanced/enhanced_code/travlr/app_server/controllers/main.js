const tripsEndpoint = 'http://localhost:3000/api/trips';
const options = {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
};

/* GET Homepage - shows a short welcome plus three trips pulled live
   from the trips API (same fetch-the-API pattern travel.js uses for
   the full catalog), so the home page never drifts out of sync with
   what is actually in the database. */
const index = async (req, res) => {
    try {
        const apiRes = await fetch(tripsEndpoint, options);
        const json = await apiRes.json();
        const trips = Array.isArray(json) ? json.slice(0, 3) : [];
        res.render('index', { title: 'Travlr Getaways', nav: 'home', trips });
    } catch (err) {
        // The catalog API being unreachable shouldn't take the whole
        // home page down; render without featured trips instead.
        res.render('index', { title: 'Travlr Getaways', nav: 'home', trips: [] });
    }
};

/* GET About page */
const about = (req, res) => {
    res.render('about', { title: 'About - Travlr Getaways', nav: 'about' });
};

module.exports = {
    index,
    about
};