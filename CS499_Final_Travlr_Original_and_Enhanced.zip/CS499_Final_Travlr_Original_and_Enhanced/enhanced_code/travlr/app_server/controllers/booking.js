const bookingsEndpoint = 'http://localhost:3000/api/bookings';

/* POST /booking - forwards a booking request from the Travel page to
   the public POST /api/bookings endpoint. This is the same
   fetch-the-API pattern contact.js uses for the Contact form, and for
   the same reason: validation, sanitization, and storage stay in one
   place shared with the rest of the API instead of the customer site
   writing to MongoDB on its own.

   Either outcome renders booking.hbs — a confirmation naming the trip,
   or the reason the request was refused together with the values the
   visitor typed, so nothing has to be retyped after a correction. */
const submitBooking = async (req, res) => {
    const tripCode = req.body.tripCode;
    const tripName = req.body.tripName;
    const name = req.body.name;
    const email = req.body.email;
    const travellers = req.body.travellers;
    const notes = req.body.notes;

    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({ tripCode, name, email, travellers, notes })
    };

    try {
        const apiRes = await fetch(bookingsEndpoint, options);
        const body = await apiRes.json();
        if (apiRes.ok) {
            return res.render('booking', {
                title: 'Booking request sent - Travlr Getaways',
                nav: 'travel',
                success: true,
                // The API answers with the stored record, so the trip
                // name shown back is the catalog's own name rather
                // than whatever the submitted form said.
                booking: body
            });
        }
        return res.render('booking', {
            title: 'Booking request - Travlr Getaways',
            nav: 'travel',
            error: body.message || 'Something went wrong sending your booking request.',
            values: { tripCode, tripName, name, email, travellers, notes }
        });
    } catch (err) {
        return res.render('booking', {
            title: 'Booking request - Travlr Getaways',
            nav: 'travel',
            error: 'Something went wrong sending your booking request.',
            values: { tripCode, tripName, name, email, travellers, notes }
        });
    }
};

module.exports = {
    submitBooking
};
