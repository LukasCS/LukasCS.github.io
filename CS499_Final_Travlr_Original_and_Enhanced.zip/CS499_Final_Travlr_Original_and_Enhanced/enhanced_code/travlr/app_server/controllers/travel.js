// Fetches from /trips/search rather than the plain /trips list. This
// endpoint returns the same trips (limit=50 covers the whole catalog,
// same as the plain list's no-page-size-limit behavior) but its
// response is ALSO where the ratings feature attaches community
// averages (see tripsQuery.js's tripsSearch, which merges
// ratings.js's attachCommunityRatings into every result). Sourcing the
// customer site from this endpoint means the community rating line
// below reuses the exact data the API already computed, instead of
// the customer site re-deriving or re-fetching it a second way.
const { toViewModel } = require('../lib/tripView');

const tripsSearchEndpoint = 'http://localhost:3000/api/trips/search?limit=50';
const options = {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
};

// var fs = require('fs');
// var trips = JSON.parse(fs.readFileSync('./data/trips.json','utf8'));

/* GET travel view */
const travel = async function(req, res, next) {
    // console.log('TRAVEL CONTROLLER BEGIN');
    await fetch(tripsSearchEndpoint, options)
        .then(res => res.json())
        .then(json => {
            let message = null;
            let trips = Array.isArray(json.results) ? json.results : null;
            if (!trips) {
                message = 'API lookup error';
                trips = [];
            } else if (!trips.length) {
                message = 'No trips exist in our database!';
            }
            // Price, departure date, and community rating are turned
            // into display strings here (see app_server/lib/tripView.js)
            // so travel.hbs stays a plain, logicless view.
            trips = trips.map(toViewModel);
            res.render('travel', { title: 'Travel - Travlr Getaways', nav: 'travel', trips, message });
        })
        .catch(err => res.status(500).send(err.message));
};

module.exports = {
    travel
};
