const contactEndpoint = 'http://localhost:3000/api/contact';

/* GET contact view */
const showForm = (req, res) => {
    res.render('contact', { title: 'Contact - Travlr Getaways', nav: 'contact' });
};

/* POST contact view - forwards the submitted message to the public
   POST /api/contact endpoint (same fetch-the-API pattern travel.js
   uses for the trips catalog) rather than writing to MongoDB
   directly, so validation, sanitization, and storage stay in one
   place shared with the rest of the API. The page is re-rendered with
   a success confirmation, or with the API's validation error and the
   values the visitor typed so they don't have to retype the form. */
const submitForm = async (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const message = req.body.message;

    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({ name, email, message })
    };

    try {
        const apiRes = await fetch(contactEndpoint, options);
        const body = await apiRes.json();
        if (apiRes.ok) {
            return res.render('contact', {
                title: 'Contact - Travlr Getaways',
                nav: 'contact',
                success: true
            });
        }
        return res.render('contact', {
            title: 'Contact - Travlr Getaways',
            nav: 'contact',
            error: body.message || 'Something went wrong sending your message.',
            values: { name, email, message }
        });
    } catch (err) {
        return res.render('contact', {
            title: 'Contact - Travlr Getaways',
            nav: 'contact',
            error: 'Something went wrong sending your message.',
            values: { name, email, message }
        });
    }
};

module.exports = {
    showForm,
    submitForm
};