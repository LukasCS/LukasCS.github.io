// User model. The Angular version was a class with a constructor that
// initialized empty strings; in idiomatic TypeScript/React an interface
// plus object literals is lighter weight and equally type safe.
export interface User {
  email: string;
  name: string;
  // Enhancement Three: RBAC role from the JWT claim. Optional because
  // tokens issued before the role existed omit it (treated as 'user').
  role?: string;
}
