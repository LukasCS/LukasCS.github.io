// Trip interface — direct TypeScript port of the Angular model
// (app_admin/src/app/models/trip.ts). Interfaces give compile-time
// type safety across the API layer, context, and components.
// Community rating summary attached to search results (see
// ratings.js's attachCommunityRatings on the API side). Deliberately
// named `communityRating`, not `rating`, to stay visually distinct
// from the resort star class embedded in the `resort` string below —
// the two are unrelated concepts. null means the trip has no ratings
// yet; absent (optional) covers responses that never attach this
// field at all (e.g. the recommendations endpoint).
export interface CommunityRating {
  average: number;
  count: number;
}

export interface Trip {
  _id: string;
  code: string;
  name: string;
  length: string;
  start: string; // ISO date string as returned by the Express API
  resort: string;
  perPerson: number; // Enhancement Three: schema stores a Number now
  image: string;
  description: string;
  communityRating?: CommunityRating | null;
}

// Shape of the add/edit form before a trip has an _id assigned by
// MongoDB. Form inputs are text, so the draft keeps perPerson as a
// string; TripForm converts it to a number at submit time to match
// the Enhancement Three schema type.
// communityRating is excluded here the same way perPerson is: it is a
// server-computed, read-only figure (see ratings.js), never a field
// the add/edit trip form collects or submits.
export type TripFormData = Omit<Trip, '_id' | 'perPerson' | 'communityRating'> & {
  _id?: string;
  perPerson: string;
};

// Converts a validated form draft into the API payload shape.
export function toTripPayload(form: TripFormData): Omit<Trip, '_id'> & { _id?: string } {
  return { ...form, perPerson: Number(form.perPerson) };
}
