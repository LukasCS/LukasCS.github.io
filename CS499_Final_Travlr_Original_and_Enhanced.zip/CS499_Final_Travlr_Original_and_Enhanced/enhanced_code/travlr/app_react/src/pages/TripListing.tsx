// Trip listing page — extended for CS 499 Enhancement Two.
//
// The page now drives the algorithm endpoints added to the API:
//   - a search box (server-side relevance scoring)
//   - a sort selector (server-side stable merge sort)
//   - a "Load more" button (cursor-based pagination)
//   - a "Similar trips" panel (hash map + bounded min-heap top-k)
//
// All heavy work happens on the server; this component only manages
// query state and appends pages as they arrive.
import { FormEvent, useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import TripCard from '../components/TripCard';
import { Trip } from '../models/trip';
import {
  searchTrips,
  getRecommendations,
  getTripStats,
  getSuggestions,
  CatalogStats,
  RecommendedTrip,
  SortField
} from '../api/trip-api';
import { useAuth } from '../context/AuthContext';

const PAGE_SIZE = 6;
const SUGGEST_MIN_LENGTH = 2;
const SUGGEST_DEBOUNCE_MS = 250;

export default function TripListing() {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [totalMatches, setTotalMatches] = useState(0);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [message, setMessage] = useState('Loading trips...');
  const [isLoading, setIsLoading] = useState(false);

  // Query controls
  const [searchInput, setSearchInput] = useState('');
  const [activeSearch, setActiveSearch] = useState('');
  const [sortBy, setSortBy] = useState<SortField>('name');
  const [order, setOrder] = useState<'asc' | 'desc'>('asc');

  // Price/rating filters (database-side, pushed down into the
  // aggregation pipeline / application engine alongside search+sort).
  // '' means "Any" — no filter sent to the API.
  const [maxPrice, setMaxPrice] = useState('');
  const [rating, setRating] = useState('');

  // Autocomplete suggestions (trie-backed): a native <datalist> fed by
  // the /trips/suggest endpoint. Debounced so the trie is not rebuilt
  // server-side on every single keystroke, and gated on a minimum
  // length so it never fires for a one-character prefix.
  const [suggestions, setSuggestions] = useState<string[]>([]);

  // Recommendations
  const [seedCode, setSeedCode] = useState('');
  const [recommendations, setRecommendations] = useState<RecommendedTrip[]>([]);
  const [recError, setRecError] = useState('');

  const { isAdmin } = useAuth();
  const navigate = useNavigate();

  // Catalog insights (Enhancement Three): one aggregation-pipeline
  // request on mount; failures degrade silently to no strip.
  const [stats, setStats] = useState<CatalogStats | null>(null);
  useEffect(() => {
    getTripStats().then(setStats).catch(() => setStats(null));
  }, []);

  // Loads the first page for the current query (replaces the list).
  const loadFirstPage = useCallback(async (
    search: string,
    sort: SortField,
    ord: 'asc' | 'desc',
    maxPriceFilter: string,
    ratingFilter: string
  ) => {
    setIsLoading(true);
    try {
      const page = await searchTrips({
        search,
        sortBy: sort,
        order: ord,
        limit: PAGE_SIZE,
        maxPrice: maxPriceFilter ? Number(maxPriceFilter) : undefined,
        rating: ratingFilter ? Number(ratingFilter) : undefined
      });
      setTrips(page.results);
      setTotalMatches(page.totalMatches);
      setNextCursor(page.nextCursor);
      setMessage(
        page.totalMatches === 0
          ? (search
            ? `No trips matched "${search}".`
            : 'There were no trips retrieved from the database')
          : ''
      );
    } catch {
      setMessage('Unable to load trips. Is the API running?');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    // A new search/sort context invalidates the recommendation panel:
    // leaving it rendered above fresh results made the page look like
    // the search had done nothing (a stale-state bug found in manual
    // testing and now covered by a regression test).
    setSeedCode('');
    setRecommendations([]);
    setRecError('');
    loadFirstPage(activeSearch, sortBy, order, maxPrice, rating);
  }, [activeSearch, sortBy, order, maxPrice, rating, loadFirstPage]);

  // If the search is cleared while sorted by relevance, relevance no
  // longer means anything (and its option unmounts) — fall back to name.
  useEffect(() => {
    if (!activeSearch && sortBy === 'relevance') {
      setSortBy('name');
      setOrder('asc');
    }
  }, [activeSearch, sortBy]);

  useEffect(() => {
    const trimmed = searchInput.trim();
    if (trimmed.length < SUGGEST_MIN_LENGTH) {
      setSuggestions([]);
      return;
    }
    const timer = setTimeout(() => {
      getSuggestions(trimmed).then(setSuggestions).catch(() => setSuggestions([]));
    }, SUGGEST_DEBOUNCE_MS);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const handleSearchSubmit = (event: FormEvent) => {
    event.preventDefault();
    setActiveSearch(searchInput.trim());
  };

  // Appends the next page using the cursor from the previous response.
  const handleLoadMore = async () => {
    if (!nextCursor) {
      return;
    }
    setIsLoading(true);
    try {
      const page = await searchTrips({
        search: activeSearch,
        sortBy,
        order,
        limit: PAGE_SIZE,
        cursor: nextCursor,
        maxPrice: maxPrice ? Number(maxPrice) : undefined,
        rating: rating ? Number(rating) : undefined
      });
      setTrips((previous) => [...previous, ...page.results]);
      setNextCursor(page.nextCursor);
    } catch {
      setMessage('Unable to load more trips.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRecommend = async (code: string) => {
    setSeedCode(code);
    setRecError('');
    setRecommendations([]);
    if (!code) {
      return;
    }
    try {
      setRecommendations(await getRecommendations(code, 3));
    } catch {
      setRecError('Unable to load recommendations.');
    }
  };

  return (
    <>
      <div className="row align-items-end mb-3">
        {isAdmin && (
          <div className="col-auto">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => navigate('/add-trip')}
            >
              Add Trip
            </button>
          </div>
        )}
        <div className="col-md-4">
          <form onSubmit={handleSearchSubmit}>
            <label htmlFor="trip-search">Search trips</label>
            <div className="input-group">
              <input
                id="trip-search"
                type="search"
                className="form-control"
                placeholder="e.g. reef, family, luxury"
                value={searchInput}
                onChange={(event) => setSearchInput(event.target.value)}
                list="trip-search-suggestions"
                autoComplete="off"
              />
              <button type="submit" className="btn btn-info">
                Search
              </button>
            </div>
            <datalist id="trip-search-suggestions">
              {suggestions.map((suggestion) => (
                <option key={suggestion} value={suggestion} />
              ))}
            </datalist>
          </form>
        </div>
        <div className="col-auto">
          <label htmlFor="trip-sort">Sort by</label>
          <select
            id="trip-sort"
            className="form-select"
            value={`${sortBy}:${order}`}
            onChange={(event) => {
              const [field, direction] = event.target.value.split(':');
              setSortBy(field as SortField);
              setOrder(direction as 'asc' | 'desc');
            }}
          >
            {activeSearch && <option value="relevance:desc">Best match</option>}
            <option value="name:asc">Name (A to Z)</option>
            <option value="name:desc">Name (Z to A)</option>
            <option value="price:asc">Price (low to high)</option>
            <option value="price:desc">Price (high to low)</option>
            <option value="start:asc">Start date (earliest)</option>
            <option value="start:desc">Start date (latest)</option>
          </select>
        </div>
        <div className="col-auto">
          <label htmlFor="trip-max-price">Max price</label>
          <select
            id="trip-max-price"
            className="form-select"
            value={maxPrice}
            onChange={(event) => setMaxPrice(event.target.value)}
          >
            <option value="">Any</option>
            <option value="1000">$1,000</option>
            <option value="1500">$1,500</option>
            <option value="2000">$2,000</option>
            <option value="2500">$2,500</option>
            <option value="3000">$3,000</option>
          </select>
        </div>
        <div className="col-auto">
          <label htmlFor="trip-rating">Rating</label>
          <select
            id="trip-rating"
            className="form-select"
            value={rating}
            onChange={(event) => setRating(event.target.value)}
          >
            <option value="">Any</option>
            <option value="2">2+</option>
            <option value="3">3+</option>
            <option value="4">4+</option>
            <option value="5">5 stars</option>
          </select>
        </div>
        <div className="col-auto">
          <label htmlFor="trip-similar">Similar to</label>
          <select
            id="trip-similar"
            className="form-select"
            value={seedCode}
            onChange={(event) => handleRecommend(event.target.value)}
          >
            <option value="">Choose a trip...</option>
            {trips.map((trip) => (
              <option key={trip.code} value={trip.code}>
                {trip.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {seedCode && (
        <div className="mb-4">
          <h5>
            Trips similar to {trips.find((t) => t.code === seedCode)?.name || seedCode}{' '}
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary ms-2"
              onClick={() => handleRecommend('')}
            >
              Clear
            </button>
          </h5>
          {recError && <p>{recError}</p>}
          <div className="row">
            {recommendations.map((trip) => (
              <div className="col-md-4 col-sm-6 col-12 mb-3" key={`rec-${trip.code}`}>
                {/* Surfacing the similarity score makes the ranking
                    inspectable instead of a black box. */}
                <p className="text-muted mb-1">
                  Similarity score: {trip.similarity.toFixed(1)}
                </p>
                <TripCard trip={trip} />
              </div>
            ))}
          </div>
          <hr />
        </div>
      )}

      {stats && stats.overall.totalTrips > 0 && (
        <p className="text-muted">
          Catalog insights: {stats.overall.totalTrips} trips, from{' '}
          {stats.overall.minPrice.toLocaleString('en-US', { style: 'currency', currency: 'USD' })} to{' '}
          {stats.overall.maxPrice.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
          {' '}(average {stats.overall.avgPrice.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}).{' '}
          {stats.byRating.map((r) => `${r.count}× ${r.rating}-star`).join(', ')}.
        </p>
      )}
      {message && <p>{message}</p>}
      {totalMatches > 0 && (
        <p className="text-muted">
          Showing {trips.length} of {totalMatches} trip{totalMatches === 1 ? '' : 's'}
          {activeSearch ? ` matching "${activeSearch}"` : ''}
        </p>
      )}
      <div className="row">
        {trips.map((trip) => (
          <div className="col-md-4 col-sm-6 col-12 mb-3" key={trip.code}>
            <TripCard trip={trip} />
          </div>
        ))}
      </div>
      {nextCursor && (
        <div className="row mb-4">
          <div className="col-12 text-center">
            <button
              type="button"
              className="btn btn-outline-info"
              onClick={handleLoadMore}
              disabled={isLoading}
            >
              {isLoading ? 'Loading...' : 'Load more trips'}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
