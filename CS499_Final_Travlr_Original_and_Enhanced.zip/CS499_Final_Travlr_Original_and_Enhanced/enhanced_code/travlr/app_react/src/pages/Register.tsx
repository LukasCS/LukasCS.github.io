// Registration page — added in CS 499 Enhancement Three.
//
// The original application (and the first two enhancements) had no
// registration interface at all: accounts could only be created by
// calling POST /api/register directly. With role-based access control
// in place, a registration page completes the story visibly: every
// account created here is an ordinary 'user' (the API ignores any
// role a client might smuggle into the request), and administrative
// rights are grantable only through the operator promotion script.
import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setFormError('');

    if (!email || !password || !name) {
      setFormError('All fields are required, please try again');
      return;
    }

    try {
      await register({ name, email }, password);
      navigate('/');
    } catch {
      setFormError('Registration failed. The email may already be in use.');
    }
  };

  return (
    <div className="row">
      <div className="col-12 col-md-8">
        <h2>Register</h2>
        <p className="text-muted">
          New accounts are standard users. Administrative access is
          granted separately by an operator.
        </p>
        <form onSubmit={handleSubmit} noValidate>
          {formError && (
            <div role="alert" className="alert alert-danger">
              {formError}
            </div>
          )}
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              id="name"
              type="text"
              placeholder="Enter Name"
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <input
              id="email"
              type="email"
              placeholder="Enter email address"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              className="form-control"
              placeholder="e.g 12+ alphanumerics"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Create Account
          </button>
        </form>
        <p className="mt-3">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
