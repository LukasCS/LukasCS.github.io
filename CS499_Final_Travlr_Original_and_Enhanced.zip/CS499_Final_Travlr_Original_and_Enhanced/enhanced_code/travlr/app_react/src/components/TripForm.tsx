// Shared trip form used by both the Add Trip and Edit Trip pages.
//
// In the Angular application, AddTripComponent and EditTripComponent
// each built an identical nine-field ReactiveForms FormGroup and an
// identical ~120-line template — roughly 240 duplicated lines. This
// component consolidates that duplication into a single controlled
// form driven by useState, with the same required-field validation
// the Validators.required rules enforced. The page components only
// supply initial values and an onSubmit handler.
import { FormEvent, useEffect, useState } from 'react';
import axios from 'axios';
import { TripFormData } from '../models/trip';

interface TripFormProps {
  title: string;
  initialValues?: TripFormData;
  onSubmit: (formData: TripFormData) => Promise<void>;
}

const EMPTY_FORM: TripFormData = {
  code: '',
  name: '',
  length: '',
  start: '',
  resort: '',
  perPerson: '',
  image: '',
  description: ''
};

// Field metadata drives both rendering and validation, so adding a
// field to the schema is a one-line change here instead of a
// copy/paste block in two templates.
const FIELDS: Array<{
  key: keyof Omit<TripFormData, '_id'>;
  label: string;
  type: 'text' | 'date';
  requiredMessage: string;
}> = [
  { key: 'code', label: 'Code:', type: 'text', requiredMessage: 'Trip Code is required' },
  { key: 'name', label: 'Name:', type: 'text', requiredMessage: 'Name is required' },
  { key: 'length', label: 'Length:', type: 'text', requiredMessage: 'Length is required' },
  { key: 'start', label: 'Start:', type: 'date', requiredMessage: 'Date is required' },
  { key: 'resort', label: 'Resort:', type: 'text', requiredMessage: 'Resort is required' },
  { key: 'perPerson', label: 'Per Person:', type: 'text', requiredMessage: 'Per Person is required and must be a non-negative number' },
  { key: 'image', label: 'Image Name:', type: 'text', requiredMessage: 'Image Name must be a filename ending in .jpg, .jpeg, .png, or .webp (e.g. desert1.jpg)' },
  { key: 'description', label: 'Description:', type: 'text', requiredMessage: 'Description is required' }
];

export function validateTripForm(values: TripFormData): string[] {
  return FIELDS.filter((field) => {
    if (!values[field.key].trim()) {
      return true;
    }
    // Enhancement Three: the API schema stores perPerson as a Number
    // with a non-negative constraint; catch bad input before submit.
    if (field.key === 'perPerson') {
      const price = Number(values.perPerson);
      return Number.isNaN(price) || price < 0;
    }
    // Enhancement Three: the schema accepts only bare image filenames
    // (blocking path traversal); validate the same rule client-side so
    // a missing extension is explained before the request is sent.
    if (field.key === 'image') {
      return !/^[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/.test(values.image.trim());
    }
    return false;
  }).map((field) => field.key);
}

export default function TripForm({
  title,
  initialValues,
  onSubmit
}: TripFormProps) {
  const [values, setValues] = useState<TripFormData>(
    initialValues ?? EMPTY_FORM
  );
  const [submitted, setSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState('');

  // When the edit page finishes loading the trip, sync it into state.
  useEffect(() => {
    if (initialValues) {
      setValues(initialValues);
    }
  }, [initialValues]);

  const invalidFields = validateTripForm(values);

  const handleChange = (key: keyof Omit<TripFormData, '_id'>, value: string) => {
    setValues((previous) => ({ ...previous, [key]: value }));
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitted(true);
    setSubmitError('');
    if (invalidFields.length > 0) {
      return;
    }
    try {
      await onSubmit(values);
    } catch (error) {
      // The API's error handler returns the precise validation reason
      // (e.g. "Image must be a bare image filename"); show it instead
      // of a generic line so the user can actually fix the input.
      const serverMessage = axios.isAxiosError(error)
        ? (error.response?.data as { message?: string } | undefined)?.message
        : undefined;
      setSubmitError(
        typeof serverMessage === 'string' && serverMessage.length > 0
          ? `The trip could not be saved: ${serverMessage}`
          : 'The trip could not be saved. Please try again.'
      );
    }
  };

  return (
    <div className="col-md-4">
      <h2 className="text-center">{title}</h2>
      {submitError && (
        <div role="alert" className="alert alert-danger">
          {submitError}
        </div>
      )}
      <form onSubmit={handleSubmit} noValidate>
        {FIELDS.map((field) => {
          // Single source of truth: the same validateTripForm result
          // that gates submission also drives the error display. (An
          // earlier version duplicated an emptiness-only check here,
          // so format rules blocked the submit without any message.)
          const isInvalid = submitted && invalidFields.includes(field.key);
          return (
            <div className="form-group" key={field.key}>
              <label htmlFor={field.key}>{field.label}</label>
              <input
                id={field.key}
                type={field.type}
                placeholder={field.label.replace(':', '')}
                className={`form-control${isInvalid ? ' is-invalid' : ''}`}
                value={values[field.key]}
                onChange={(event) => handleChange(field.key, event.target.value)}
              />
              {isInvalid && <div>{field.requiredMessage}</div>}
            </div>
          );
        })}
        <button type="submit" className="btn btn-info mt-3">
          Save
        </button>
      </form>
    </div>
  );
}
