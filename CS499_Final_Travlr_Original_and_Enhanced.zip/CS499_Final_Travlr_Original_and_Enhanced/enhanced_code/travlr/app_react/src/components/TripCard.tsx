// Presentational card for one trip. Port of the Angular
// TripCardComponent with two deliberate design changes:
//
// 1. The @Input('trip') was typed as `any`; here the prop is the Trip
//    interface, so the compiler verifies every field access.
// 2. The Angular version stashed the trip code in localStorage and
//    navigated to a fixed /edit-trip URL. That made edit links
//    unbookmarkable and coupled two components through shared browser
//    state. The React version encodes the code in the route itself
//    (/edit-trip/:tripCode), which is the standard SPA pattern.
//
// The original template also bound trip.description with [innerHTML],
// which renders unsanitized markup — a stored XSS vector if a trip
// description ever contains a script payload. React escapes
// interpolated text by default, so rendering {trip.description} as
// plain text closes that hole.
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CommunityRating, Trip } from '../models/trip';
import { useAuth } from '../context/AuthContext';
import { getMyRating, rateTrip } from '../api/trip-api';

interface TripCardProps {
  trip: Trip;
}

const STAR_VALUES = [1, 2, 3, 4, 5];

// Formats the community rating line. Named and worded to stay clearly
// distinct from the resort star class rendered just above it
// (trip.resort, e.g. "Emerald Bay, 3 stars") — that is the PROPERTY's
// tier, set by the catalog; this is what visitors who rated the TRIP
// thought of it.
function formatCommunityRating(rating: CommunityRating | null | undefined): string {
  if (!rating || rating.count === 0) {
    return 'No ratings yet';
  }
  return `${rating.average.toFixed(1)} (${rating.count})`;
}

// Format the perPerson value the way Angular's currency pipe did.
// Accepts number (Enhancement Three schema type) or string (legacy).
function formatCurrency(value: number | string): string {
  const amount = Number(value);
  if (Number.isNaN(amount)) {
    return String(value);
  }
  return amount.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD'
  });
}

// Format the ISO start date for display (e.g. "Feb 14, 2021").
// Rendering the date matters for Enhancement Two: the listing can be
// sorted by start date, so the sort key must be visible on the card.
function formatStartDate(isoDate: string): string {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) {
    return '';
  }
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC'
  });
}

export default function TripCard({ trip }: TripCardProps) {
  // Enhancement Three: editing is an admin capability now, so the Edit
  // control renders only for admin tokens (the API enforces it too).
  const { isAdmin, isLoggedIn } = useAuth();

  // Community rating starts from whatever the search response already
  // carried (see ratings.js's attachCommunityRatings) and is replaced
  // with the fresh figure the rating endpoint returns after a vote, so
  // the card never has to re-fetch the whole list to show the update.
  const [communityRating, setCommunityRating] = useState(trip.communityRating ?? null);
  useEffect(() => {
    setCommunityRating(trip.communityRating ?? null);
  }, [trip.communityRating]);

  // The caller's own vote (distinct from communityRating above) is
  // fetched only when logged in, and only for this one trip — not
  // batched with the list request, since most cards on a page are
  // never rated by the viewer and fetching all of them eagerly would
  // be wasted work.
  const [myRating, setMyRating] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [ratingError, setRatingError] = useState('');

  useEffect(() => {
    if (!isLoggedIn) {
      setMyRating(null);
      return undefined;
    }
    let cancelled = false;
    getMyRating(trip.code)
      .then((stars) => {
        if (!cancelled) {
          setMyRating(stars);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setMyRating(null);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [isLoggedIn, trip.code]);

  const handleRate = async (stars: number) => {
    setIsSaving(true);
    setRatingError('');
    try {
      const result = await rateTrip(trip.code, stars);
      // Immediate feedback: both the caller's own star display and the
      // community average/count update from this single response,
      // with no need to re-fetch the trip or the search page.
      setMyRating(result.stars);
      setCommunityRating(result.communityRating);
    } catch {
      setRatingError('Unable to save your rating.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="card">
      <div className="card-header">{trip.name}</div>
      <img
        src={`/assets/images/${trip.image}`}
        alt="trip thumbnail"
        className="card-img-top"
      />
      <div className="card-body">
        <h6 className="card-subtitle mb-2 text-muted">{trip.resort}</h6>
        {formatStartDate(trip.start) && (
          <p className="card-subtitle mb-2 text-muted">
            Departs {formatStartDate(trip.start)}
          </p>
        )}
        <p className="card-subtitle mt-3 mb-3 text-muted">
          {trip.length} only {formatCurrency(trip.perPerson)} per person
        </p>
        <p className="card-text">{trip.description}</p>

        {/* Community rating: visitor sentiment about the TRIP, kept
            visually and textually separate from the resort star class
            in the h6 above (a property tier, not a visitor opinion). */}
        <p className="card-subtitle mb-2 text-muted">
          Community rating: {formatCommunityRating(communityRating)}
        </p>
        {isLoggedIn && (
          <div className="mb-2" role="group" aria-label="Rate this trip">
            {STAR_VALUES.map((value) => (
              <button
                key={value}
                type="button"
                className="btn btn-link p-0 me-1"
                disabled={isSaving}
                onClick={() => handleRate(value)}
                aria-label={`Rate ${value} star${value === 1 ? '' : 's'}`}
                aria-pressed={myRating !== null && value <= myRating}
              >
                {myRating !== null && value <= myRating ? '★' : '☆'}
              </button>
            ))}
            {ratingError && (
              <span className="text-danger ms-2">{ratingError}</span>
            )}
          </div>
        )}

        {isAdmin && (
          <Link
            to={`/edit-trip/${trip.code}`}
            className="btn btn-info"
            role="button"
          >
            Edit Trip
          </Link>
        )}
      </div>
    </div>
  );
}
