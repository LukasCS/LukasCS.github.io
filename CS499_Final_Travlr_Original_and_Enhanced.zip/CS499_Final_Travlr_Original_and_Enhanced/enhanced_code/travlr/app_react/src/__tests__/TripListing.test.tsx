// Regression tests for the trip listing's query state — added after
// manual testing found that the recommendations panel persisted across
// a new search, visually masking the fresh results.
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import TripListing from '../pages/TripListing';
import { AuthProvider } from '../context/AuthContext';
import { Trip } from '../models/trip';

jest.mock('../api/trip-api', () => ({
  searchTrips: jest.fn(),
  getRecommendations: jest.fn(),
  getTripStats: jest.fn(),
  getSuggestions: jest.fn(),
  // TripCard (rendered for every result) reads these when logged in.
  // None of these tests log in, but mocking keeps the module shape
  // complete rather than relying on that never changing.
  getMyRating: jest.fn().mockResolvedValue(null),
  rateTrip: jest.fn()
}));
import { searchTrips, getRecommendations, getTripStats, getSuggestions } from '../api/trip-api';

const mockSearch = searchTrips as jest.Mock;
const mockRecs = getRecommendations as jest.Mock;
const mockStats = getTripStats as jest.Mock;
const mockSuggest = getSuggestions as jest.Mock;

function trip(code: string, name: string): Trip {
  return {
    _id: code, code, name,
    length: '4 nights / 5 days',
    start: '2027-01-01T08:00:00.000Z',
    resort: 'Testing Bay, 3 stars',
    perPerson: 500,
    image: 'reef1.jpg',
    description: `${name} description`
  };
}

function page(trips: Trip[], total = trips.length) {
  return { results: trips, totalMatches: total, nextCursor: null, sortBy: 'name', order: 'asc' };
}

function renderListing() {
  return render(
    <AuthProvider>
      <MemoryRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <TripListing />
      </MemoryRouter>
    </AuthProvider>
  );
}

beforeEach(() => {
  localStorage.clear();
  mockSearch.mockReset();
  mockRecs.mockReset();
  mockStats.mockReset();
  mockSuggest.mockReset();
  // The insights strip renders only when trips exist; default to an
  // empty catalog so listing tests stay focused on their own concern.
  mockStats.mockResolvedValue({ overall: { totalTrips: 0, avgPrice: 0, minPrice: 0, maxPrice: 0 }, byRating: [], priceBands: [] });
  mockSuggest.mockResolvedValue([]);
});

test('submitting a search replaces the listed trips', async () => {
  mockSearch
    .mockResolvedValueOnce(page([trip('A1', 'Alpha Reef'), trip('B1', 'Beta Bay')]))
    .mockResolvedValueOnce(page([trip('A1', 'Alpha Reef')], 1));

  renderListing();
  await screen.findAllByText('Alpha Reef');

  fireEvent.change(screen.getByLabelText('Search trips'), { target: { value: 'alpha' } });
  fireEvent.click(screen.getByRole('button', { name: 'Search' }));

  await waitFor(() => expect(screen.queryAllByText('Beta Bay')).toHaveLength(0));
  expect(screen.getAllByText('Alpha Reef').length).toBeGreaterThan(0);
  expect(mockSearch).toHaveBeenLastCalledWith(
    expect.objectContaining({ search: 'alpha' })
  );
});

test('recommendations panel clears when a new search is submitted', async () => {
  mockSearch.mockResolvedValue(page([trip('A1', 'Alpha Reef'), trip('B1', 'Beta Bay')]));
  mockRecs.mockResolvedValue([{ ...trip('B1', 'Beta Bay'), similarity: 2.5 }]);

  renderListing();
  await screen.findAllByText('Alpha Reef');

  // Open the recommendations panel.
  fireEvent.change(screen.getByLabelText('Similar to'), { target: { value: 'A1' } });
  await screen.findByText(/Trips similar to Alpha Reef/);

  // A new search must dismiss the now-stale panel.
  fireEvent.change(screen.getByLabelText('Search trips'), { target: { value: 'beta' } });
  fireEvent.click(screen.getByRole('button', { name: 'Search' }));

  await waitFor(() =>
    expect(screen.queryByText(/Trips similar to/)).not.toBeInTheDocument()
  );
});

test('typing 2+ characters fetches suggestions (debounced) and populates the datalist', async () => {
  jest.useFakeTimers({ advanceTimers: true });
  mockSearch.mockResolvedValue(page([trip('A1', 'Alpha Reef')]));
  mockSuggest.mockResolvedValue(['reef', 'resort']);

  renderListing();
  await screen.findAllByText('Alpha Reef');

  fireEvent.change(screen.getByLabelText('Search trips'), { target: { value: 're' } });

  // Below the 250ms debounce, no suggestion request has gone out yet.
  expect(mockSuggest).not.toHaveBeenCalled();

  jest.advanceTimersByTime(250);
  await waitFor(() => expect(mockSuggest).toHaveBeenCalledWith('re'));

  await waitFor(() => {
    const options = document.querySelectorAll('#trip-search-suggestions option');
    expect(Array.from(options).map((o) => o.getAttribute('value'))).toEqual(['reef', 'resort']);
  });

  jest.useRealTimers();
});

test('a single character does not trigger a suggestions request', async () => {
  jest.useFakeTimers({ advanceTimers: true });
  mockSearch.mockResolvedValue(page([trip('A1', 'Alpha Reef')]));

  renderListing();
  await screen.findAllByText('Alpha Reef');

  fireEvent.change(screen.getByLabelText('Search trips'), { target: { value: 'r' } });
  jest.advanceTimersByTime(250);

  expect(mockSuggest).not.toHaveBeenCalled();
  jest.useRealTimers();
});

test('changing the max price filter reruns the search from the first page', async () => {
  mockSearch
    .mockResolvedValueOnce(page([trip('A1', 'Alpha Reef'), trip('B1', 'Beta Bay')]))
    .mockResolvedValueOnce(page([trip('A1', 'Alpha Reef')], 1));

  renderListing();
  await screen.findAllByText('Alpha Reef');

  fireEvent.change(screen.getByLabelText('Max price'), { target: { value: '1500' } });

  await waitFor(() => expect(screen.queryAllByText('Beta Bay')).toHaveLength(0));
  expect(mockSearch).toHaveBeenLastCalledWith(
    expect.objectContaining({ maxPrice: 1500 })
  );
});

test('changing the rating filter composes with an active search', async () => {
  mockSearch
    .mockResolvedValueOnce(page([trip('A1', 'Alpha Reef')]))
    .mockResolvedValueOnce(page([trip('A1', 'Alpha Reef')], 1));

  renderListing();
  await screen.findAllByText('Alpha Reef');

  fireEvent.change(screen.getByLabelText('Search trips'), { target: { value: 'alpha' } });
  fireEvent.click(screen.getByRole('button', { name: 'Search' }));
  await waitFor(() => expect(mockSearch).toHaveBeenLastCalledWith(
    expect.objectContaining({ search: 'alpha' })
  ));

  fireEvent.change(screen.getByLabelText('Rating'), { target: { value: '4' } });

  await waitFor(() => expect(mockSearch).toHaveBeenLastCalledWith(
    expect.objectContaining({ search: 'alpha', rating: 4 })
  ));
});

test('recommendations panel has a Clear button that dismisses it', async () => {
  mockSearch.mockResolvedValue(page([trip('A1', 'Alpha Reef')]));
  mockRecs.mockResolvedValue([]);

  renderListing();
  await screen.findAllByText('Alpha Reef');

  fireEvent.change(screen.getByLabelText('Similar to'), { target: { value: 'A1' } });
  await screen.findByText(/Trips similar to Alpha Reef/);

  fireEvent.click(screen.getByRole('button', { name: 'Clear' }));
  await waitFor(() =>
    expect(screen.queryByText(/Trips similar to/)).not.toBeInTheDocument()
  );
});
