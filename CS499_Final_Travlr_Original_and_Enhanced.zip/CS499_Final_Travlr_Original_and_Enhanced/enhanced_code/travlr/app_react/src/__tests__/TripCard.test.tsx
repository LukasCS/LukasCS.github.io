// Component tests for TripCard using React Testing Library.
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import TripCard from '../components/TripCard';
import { AuthProvider } from '../context/AuthContext';
import { saveToken } from '../context/token-storage';
import { Trip } from '../models/trip';

// The card fetches the caller's own rating (getMyRating) whenever it
// mounts logged in, and posts to rateTrip when a star is clicked.
// Mocked here so tests never make a real network call, matching the
// pattern TripListing.test.tsx uses for its api module.
jest.mock('../api/trip-api', () => ({
  getMyRating: jest.fn(),
  rateTrip: jest.fn()
}));
import { getMyRating, rateTrip } from '../api/trip-api';

const mockGetMyRating = getMyRating as jest.Mock;
const mockRateTrip = rateTrip as jest.Mock;

const sampleTrip: Trip = {
  _id: '1',
  code: 'GALR210214',
  name: 'Gale Reef',
  length: '4 nights / 5 days',
  start: '2026-02-14T08:00:00.000Z',
  resort: 'Emerald Bay, 3 stars',
  perPerson: 799,
  image: 'reef1.jpg',
  description: 'Gale Reef Sed et augue lorem.'
};

function renderCard() {
  return render(
    <AuthProvider>
      <MemoryRouter>
        <TripCard trip={sampleTrip} />
      </MemoryRouter>
    </AuthProvider>
  );
}

function buildToken(payload: object): string {
  const encode = (part: object) =>
    btoa(JSON.stringify(part)).replace(/=+$/, '');
  return `${encode({ alg: 'none' })}.${encode(payload)}.signature`;
}

describe('TripCard', () => {
  beforeEach(() => {
    localStorage.clear();
    mockGetMyRating.mockReset().mockResolvedValue(null);
    mockRateTrip.mockReset();
  });

  test('renders the trip name, resort, and formatted price', () => {
    renderCard();
    expect(screen.getByText('Gale Reef')).toBeInTheDocument();
    expect(screen.getByText('Emerald Bay, 3 stars')).toBeInTheDocument();
    expect(
      screen.getByText(/4 nights \/ 5 days only \$799\.00 per person/)
    ).toBeInTheDocument();
  });

  test('renders the description as plain text (no HTML injection)', () => {
    render(
      <AuthProvider>
        <MemoryRouter>
          <TripCard
            trip={{ ...sampleTrip, description: '<img src=x onerror=alert(1)>' }}
          />
        </MemoryRouter>
      </AuthProvider>
    );
    // The payload must appear as literal text, not become a DOM element.
    expect(
      screen.getByText('<img src=x onerror=alert(1)>')
    ).toBeInTheDocument();
  });

  test('hides the Edit Trip link when logged out', () => {
    renderCard();
    expect(screen.queryByText('Edit Trip')).not.toBeInTheDocument();
  });

  test('hides the Edit Trip link for a logged-in non-admin user', () => {
    saveToken(buildToken({ exp: Date.now() / 1000 + 3600, email: 'a@b.c', name: 'A', role: 'user' }));
    renderCard();
    expect(screen.queryByText('Edit Trip')).not.toBeInTheDocument();
  });

  test('shows the Edit Trip link routed to the trip code for an admin', () => {
    saveToken(buildToken({ exp: Date.now() / 1000 + 3600, email: 'a@b.c', name: 'A', role: 'admin' }));
    renderCard();
    const editLink = screen.getByText('Edit Trip');
    expect(editLink).toBeInTheDocument();
    expect(editLink.closest('a')).toHaveAttribute(
      'href',
      '/edit-trip/GALR210214'
    );
  });

  test('shows "No ratings yet" when the trip has no community rating', () => {
    renderCard();
    expect(screen.getByText('Community rating: No ratings yet')).toBeInTheDocument();
  });

  test('shows the community average and count, distinct from the resort star class', () => {
    render(
      <AuthProvider>
        <MemoryRouter>
          <TripCard
            trip={{ ...sampleTrip, communityRating: { average: 4.3, count: 7 } }}
          />
        </MemoryRouter>
      </AuthProvider>
    );
    expect(screen.getByText('Community rating: 4.3 (7)')).toBeInTheDocument();
    // The resort star class line is unrelated and still present as-is.
    expect(screen.getByText('Emerald Bay, 3 stars')).toBeInTheDocument();
  });

  test('hides the clickable star control when logged out', () => {
    renderCard();
    expect(screen.queryByRole('group', { name: 'Rate this trip' })).not.toBeInTheDocument();
  });

  test('shows five clickable stars when logged in, reflecting the caller\'s existing rating', async () => {
    mockGetMyRating.mockResolvedValue(3);
    saveToken(buildToken({ exp: Date.now() / 1000 + 3600, email: 'a@b.c', name: 'A', role: 'user' }));
    renderCard();

    await waitFor(() => expect(mockGetMyRating).toHaveBeenCalledWith('GALR210214'));
    const filled = await screen.findAllByLabelText(/^Rate [1-3] stars?$/);
    expect(filled).toHaveLength(3);
    filled.forEach((star) => expect(star).toHaveTextContent('★'));
  });

  test('clicking a star rates the trip and immediately reflects the new average', async () => {
    mockRateTrip.mockResolvedValue({
      tripCode: 'GALR210214',
      stars: 5,
      communityRating: { average: 5, count: 1 }
    });
    saveToken(buildToken({ exp: Date.now() / 1000 + 3600, email: 'a@b.c', name: 'A', role: 'user' }));
    renderCard();

    await waitFor(() => expect(mockGetMyRating).toHaveBeenCalled());
    fireEvent.click(screen.getByLabelText('Rate 5 stars'));

    await waitFor(() => expect(mockRateTrip).toHaveBeenCalledWith('GALR210214', 5));
    expect(await screen.findByText('Community rating: 5.0 (1)')).toBeInTheDocument();
  });

  test('a failed rating attempt shows an inline error', async () => {
    mockRateTrip.mockRejectedValue(new Error('network error'));
    saveToken(buildToken({ exp: Date.now() / 1000 + 3600, email: 'a@b.c', name: 'A', role: 'user' }));
    renderCard();

    await waitFor(() => expect(mockGetMyRating).toHaveBeenCalled());
    fireEvent.click(screen.getByLabelText('Rate 2 stars'));

    expect(await screen.findByText('Unable to save your rating.')).toBeInTheDocument();
  });
});
