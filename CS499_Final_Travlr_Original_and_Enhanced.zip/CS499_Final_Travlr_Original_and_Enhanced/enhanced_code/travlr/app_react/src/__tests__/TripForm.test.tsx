// Validation tests for the shared TripForm component.
import { render, screen, fireEvent } from '@testing-library/react';
import TripForm, { validateTripForm } from '../components/TripForm';
import { TripFormData } from '../models/trip';

const validValues: TripFormData = {
  code: 'GALR210214',
  name: 'Gale Reef',
  length: '4 nights / 5 days',
  start: '2026-02-14',
  resort: 'Emerald Bay, 3 stars',
  perPerson: '799.00',
  image: 'reef1.jpg',
  description: 'Sed et augue lorem.'
};

describe('validateTripForm', () => {
  test('returns no invalid fields for a complete trip', () => {
    expect(validateTripForm(validValues)).toEqual([]);
  });

  test('flags every empty required field', () => {
    const invalid = validateTripForm({ ...validValues, code: '', name: ' ' });
    expect(invalid).toContain('code');
    expect(invalid).toContain('name');
    expect(invalid).toHaveLength(2);
  });
});

describe('TripForm', () => {
  test('blocks submission and shows messages when fields are empty', () => {
    const onSubmit = jest.fn().mockResolvedValue(undefined);
    render(<TripForm title="Add Trip" onSubmit={onSubmit} />);

    fireEvent.click(screen.getByRole('button', { name: 'Save' }));

    expect(onSubmit).not.toHaveBeenCalled();
    expect(screen.getByText('Trip Code is required')).toBeInTheDocument();
    expect(screen.getByText('Name is required')).toBeInTheDocument();
  });

  test('submits the entered values when the form is valid', () => {
    const onSubmit = jest.fn().mockResolvedValue(undefined);
    render(
      <TripForm title="Edit Trip" initialValues={validValues} onSubmit={onSubmit} />
    );

    fireEvent.click(screen.getByRole('button', { name: 'Save' }));

    expect(onSubmit).toHaveBeenCalledWith(validValues);
  });
});

// Regression tests added after a live-testing find: format rules
// (image filename, non-negative price) blocked submission but rendered
// no message, because the display logic duplicated an emptiness-only
// check instead of using validateTripForm. These prove message and
// gate can never disagree again.
describe('format validation messages (Enhancement Three)', () => {
  const filled = {
    code: 'TEST123456',
    name: 'Test Trip',
    length: '2 nights / 3 days',
    start: '2027-01-01',
    resort: 'Test Resort, 3 stars',
    perPerson: '500',
    image: 'reef1.jpg',
    description: 'A valid description.'
  };

  function fillAndSubmit(overrides: Partial<typeof filled>) {
    const values = { ...filled, ...overrides };
    render(<TripForm title="Add Trip" onSubmit={jest.fn()} />);
    for (const [key, value] of Object.entries(values)) {
      fireEvent.change(document.getElementById(key) as HTMLInputElement, {
        target: { value }
      });
    }
    fireEvent.click(screen.getByRole('button', { name: 'Save' }));
  }

  test('an image name without an extension shows the format message', () => {
    fillAndSubmit({ image: 'desert1' });
    expect(
      screen.getByText(/Image Name must be a filename ending in/)
    ).toBeInTheDocument();
  });

  test('a negative price shows the non-negative number message', () => {
    fillAndSubmit({ perPerson: '-50' });
    expect(
      screen.getByText(/Per Person is required and must be a non-negative number/)
    ).toBeInTheDocument();
  });
});
