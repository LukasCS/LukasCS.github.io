// Root component. Replaces three separate pieces of the Angular app:
//   - app.component.ts/.html (root shell with <router-outlet>)
//   - app.routes.ts (route table)
//   - app.config.ts (providers: router, HttpClient, interceptor)
//
// The route table maps one-to-one onto the Angular routes, with one
// improvement: edit-trip now carries the trip code as a URL parameter.
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import TripListing from './pages/TripListing';
import AddTrip from './pages/AddTrip';
import EditTrip from './pages/EditTrip';
import Login from './pages/Login';
import Register from './pages/Register';

export default function App() {
  return (
    <AuthProvider>
      {/* The two future flags opt into behaviours that become the
          default in the router's next major version: navigation state
          updates are wrapped in React's startTransition, and relative
          paths inside catch-all routes resolve from the matched route
          rather than the whole match. Both are enabled here so this
          application already runs the way the next version will, and
          so the library stops printing a warning for each of them on
          every render in the test output. */}
      <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <Navbar />
        <div className="container">
          <Routes>
            <Route path="/" element={<TripListing />} />
            <Route path="/add-trip" element={<AddTrip />} />
            <Route path="/edit-trip/:tripCode" element={<EditTrip />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
