// Root component. Replaces three separate pieces of the Angular app:
//   - app.component.ts/.html (root shell with <router-outlet>)
//   - app.routes.ts (route table)
//   - app.config.ts (providers: router, HttpClient, interceptor)
//
// The route table maps one-to-one onto the Angular routes, with one
// improvement: edit-trip now carries the trip code as a URL parameter.
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import TripListing from './pages/TripListing';
import AddTrip from './pages/AddTrip';
import EditTrip from './pages/EditTrip';
import Login from './pages/Login';
import Register from './pages/Register';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Navbar />
        <div className="container">
          <Routes>
            <Route path="/" element={<TripListing />} />
            <Route path="/add-trip" element={<AddTrip />} />
            <Route path="/edit-trip/:tripCode" element={<EditTrip />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Routes>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
