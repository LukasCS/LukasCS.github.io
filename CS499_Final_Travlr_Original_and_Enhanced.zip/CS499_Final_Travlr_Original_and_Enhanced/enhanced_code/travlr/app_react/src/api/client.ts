// Centralized Axios instance for all API traffic.
//
// This replaces two separate pieces of the Angular application:
//   1. HttpClient injection inside TripDataService
//   2. The JwtInterceptor class registered through HTTP_INTERCEPTORS
//
// The request interceptor attaches the JWT Bearer token to every
// outgoing request except the authentication endpoints, mirroring the
// isAuthAPI check in the original interceptor. The response
// interceptor centralizes 401 handling: if the server rejects a stale
// or invalid token, the token is dropped from storage so the UI
// immediately reflects the logged-out state.
import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import { getToken, clearToken } from '../context/token-storage';

// Where the API lives. The build tool replaces __API_BASE_URL__ with a
// literal string when it builds the bundle (see the define block in
// vite.config.ts), so a deployed build can point at a real server while
// a local build keeps the backend's default address on this machine.
// The name does not exist under the test runner, which is why the
// fallback below is needed rather than decorative.
declare const __API_BASE_URL__: string | undefined;

export const API_BASE_URL =
  typeof __API_BASE_URL__ === 'string' && __API_BASE_URL__.length > 0
    ? __API_BASE_URL__
    : 'http://localhost:3000/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' }
});

// Request interceptor: attach Authorization header when logged in.
apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const isAuthApi =
      config.url === '/login' || config.url === '/register';
    const token = getToken();
    if (token && !isAuthApi) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor: centralized handling of auth failures.
apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      clearToken();
    }
    return Promise.reject(error);
  }
);

export default apiClient;
