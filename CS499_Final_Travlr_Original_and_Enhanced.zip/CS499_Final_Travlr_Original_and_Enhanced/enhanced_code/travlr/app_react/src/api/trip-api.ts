// Typed CRUD functions for the /api/trips endpoints.
//
// This is the React counterpart of Angular's TripDataService. Instead
// of an injectable class returning RxJS Observables, each operation is
// a plain async function returning a typed Promise. Components consume
// these with async/await inside useEffect or event handlers, which
// removes the subscribe/unsubscribe lifecycle management entirely.
import apiClient from './client';
import { CommunityRating, Trip, TripFormData, toTripPayload } from '../models/trip';

export async function getTrips(): Promise<Trip[]> {
  const response = await apiClient.get<Trip[]>('/trips');
  return response.data;
}

// The Express API returns an array even for a single-code lookup, so
// this normalizes to one record (or null) at the API boundary instead
// of forcing every caller to remember that quirk, as the Angular
// EditTripComponent had to.
export async function getTrip(tripCode: string): Promise<Trip | null> {
  const response = await apiClient.get<Trip[]>(`/trips/${tripCode}`);
  return Array.isArray(response.data) ? response.data[0] ?? null : response.data;
}

export async function addTrip(formData: TripFormData): Promise<Trip> {
  // Convert the string form draft to the API's numeric perPerson.
  const response = await apiClient.post<Trip>('/trips', toTripPayload(formData));
  return response.data;
}

export async function updateTrip(formData: TripFormData): Promise<Trip> {
  const response = await apiClient.put<Trip>(
    `/trips/${formData.code}`,
    toTripPayload(formData)
  );
  return response.data;
}

export async function deleteTrip(tripCode: string): Promise<void> {
  await apiClient.delete(`/trips/${tripCode}`);
}

// ---- Enhancement Two: algorithms and data structures ----

export type SortField = 'name' | 'price' | 'start' | 'relevance';

export interface TripSearchParams {
  search?: string;
  sortBy?: SortField;
  order?: 'asc' | 'desc';
  limit?: number;
  cursor?: string | null;
  maxPrice?: number;
  rating?: number;
}

export interface TripSearchPage {
  results: Trip[];
  totalMatches: number;
  nextCursor: string | null;
  sortBy: SortField;
  order: 'asc' | 'desc';
}

// Server-side search + merge sort + cursor pagination. The cursor for
// the next page comes back in the response; passing it in the next
// call resumes exactly where the previous page ended.
export async function searchTrips(params: TripSearchParams): Promise<TripSearchPage> {
  const response = await apiClient.get<TripSearchPage>('/trips/search', {
    params: {
      search: params.search || undefined,
      sortBy: params.sortBy || undefined,
      order: params.order || undefined,
      limit: params.limit || undefined,
      cursor: params.cursor || undefined,
      maxPrice: params.maxPrice || undefined,
      rating: params.rating || undefined
    }
  });
  return response.data;
}

export interface RecommendedTrip extends Trip {
  similarity: number;
}

// Top-k similar trips, selected server-side with a bounded min-heap.
export async function getRecommendations(
  basedOn: string,
  k = 3
): Promise<RecommendedTrip[]> {
  const response = await apiClient.get<{ basedOn: string; recommendations: RecommendedTrip[] }>(
    '/trips/recommendations',
    { params: { basedOn, k } }
  );
  return response.data.recommendations;
}

// ---- Enhancement Three: catalog analytics (aggregation pipeline) ----

export interface CatalogStats {
  overall: { totalTrips: number; avgPrice: number; minPrice: number; maxPrice: number };
  byRating: { rating: number; count: number; avgPrice: number; minPrice: number; maxPrice: number }[];
  priceBands: { from: number | null; count: number }[];
}

// Catalog-wide statistics computed inside MongoDB by a single
// aggregation pipeline ($group by star rating + $bucket price bands).
export async function getTripStats(): Promise<CatalogStats> {
  const response = await apiClient.get<CatalogStats>('/trips/stats');
  return response.data;
}

// Trie-backed autocomplete for the search box. The server enforces the
// 2-character minimum and the 10-item cap; this just forwards what the
// caller asked for.
export async function getSuggestions(query: string, limit = 5): Promise<string[]> {
  const response = await apiClient.get<{ suggestions: string[] }>('/trips/suggest', {
    params: { q: query, limit }
  });
  return response.data.suggestions;
}

// ---- Trip ratings ----
//
// Distinct from the resort star class already carried on Trip.resort:
// these functions read/write the signed-in caller's OWN 1-5 vote and
// the resulting community average, computed server-side by MongoDB's
// $group/$avg (see app_api/controllers/ratings.js). Both routes
// require a valid JWT (any signed-in user, not just admins), so the
// caller is responsible for only invoking these when isLoggedIn.

export interface RateTripResponse {
  tripCode: string;
  stars: number;
  communityRating: CommunityRating;
}

// Sets or updates the caller's rating for a trip. The server upserts
// on (tripCode, userEmail), so calling this again just changes the
// caller's existing vote rather than adding a second one.
export async function rateTrip(tripCode: string, stars: number): Promise<RateTripResponse> {
  const response = await apiClient.post<RateTripResponse>(`/trips/${tripCode}/rating`, { stars });
  return response.data;
}

// The caller's own rating for a trip, or null if they have not rated
// it yet. Used to pre-select the star control when a card mounts.
export async function getMyRating(tripCode: string): Promise<number | null> {
  const response = await apiClient.get<{ stars: number | null }>(`/trips/${tripCode}/rating`);
  return response.data.stars;
}
