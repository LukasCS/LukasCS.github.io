import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The React admin SPA runs on port 4200 (same port the Angular CLI used)
// so the Express backend CORS configuration does not need to change.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 4200
  },
  // Address of the backend API, fixed into the bundle when it is built.
  // With nothing set this is the backend's default address on this
  // machine, so local development needs no configuration. A deployment
  // builds with VITE_API_BASE_URL set to its own address, for example:
  //   VITE_API_BASE_URL=https://example.org/api npm run build
  // A plain name is used here rather than import.meta.env because the
  // test runner cannot parse import.meta; where the name is undefined,
  // as it is under the test runner, the source falls back to the same
  // default.
  define: {
    __API_BASE_URL__: JSON.stringify(
      process.env.VITE_API_BASE_URL || 'http://localhost:3000/api'
    )
  }
});
