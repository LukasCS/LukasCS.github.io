require('dotenv').config();
var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./app_server/routes/index');
var usersRouter = require('./app_server/routes/users');
var travelRouter = require('./app_server/routes/travel');
var contactRouter = require('./app_server/routes/contact');
var apiRouter = require('./app_api/routes/index');
var handlebars = require('hbs');

// Small view helpers shared by the header/footer partials. `eq` lets
// the shared nav partials mark the current page as selected/active
// without duplicating a full copy of the nav per page (the problem
// with the original static HTML template, where every page had its
// own hand-edited nav). `currentYear` keeps the footer copyright line
// correct without hardcoding a year that goes stale.
handlebars.registerHelper('eq', function(a, b) {
    return a === b;
});
handlebars.registerHelper('currentYear', function() {
    return new Date().getFullYear();
});

// Wire in our authentication module
var passport = require('passport');
require('./app_api/config/passport');

// Bring in the database
require('./app_api/models/db');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'app_server', 'views'));
handlebars.registerPartials(__dirname + '/app_server/views/partials');
app.set('view engine', 'hbs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

// Enable CORS for /api routes so the Angular admin SPA (running on
// localhost:4200 during development) can call this Express backend.
// CORS — Enhancement Three tightens the code-review finding of a
// wildcard origin: only the admin SPA's origin (configurable via
// ALLOWED_ORIGIN) may make cross-origin API calls, instead of any
// site on the internet.
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'http://localhost:4200';
app.use('/api', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', ALLOWED_ORIGIN);
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  // Answer CORS preflight requests directly so they don't fall through to the API 404 handler
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travelRouter);
app.use('/contact', contactRouter);
// Strip MongoDB operator-shaped keys from every inbound request
// before any controller can touch them (NoSQL injection defense).
const sanitizeInputs = require('./app_api/middleware/sanitizeInputs');
app.use('/api', sanitizeInputs);
app.use('/api', apiRouter);

// NOTE: The previous handler here only recognized UnauthorizedError
// and neither responded nor called next() for anything else, leaving
// API requests hanging. All /api error handling is now centralized in
// app_api/middleware/errorHandler.js, mounted at the end of the API
// router, so every API failure returns a JSON status. The handlers
// below serve only the server-rendered HBS pages.

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
