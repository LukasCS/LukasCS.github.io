# Travlr Getaways

**Running online:** the customer site is at <https://travlr-cs499.duckdns.org> and the catalogue and admin application at <https://travlr-cs499-admin.duckdns.org>. Both run the code in this folder. The sample trips there are reloaded every hour, so anything changed on the public copy is temporary. `DEPLOYMENT.md` describes how that server was set up.

Travlr Getaways is a full-stack travel catalog application. The backend is an Express + MongoDB API paired with a server-rendered customer-facing site (HTML/Handlebars views served by Express). A separate React 18 + TypeScript single-page application in `app_react/` provides the admin interface for managing trips. Both frontends talk to the same Express API and MongoDB database.

## Quick start (two commands)

You need [Node.js](https://nodejs.org/) version 18 or later (tested on 24) and a local MongoDB server running on `127.0.0.1` (the default install/port). Start MongoDB, then from the `travlr/` folder run:

```
npm run setup
npm run dev
```

`npm run setup` checks that MongoDB is reachable, installs the backend and frontend dependencies (skipping either one if it's already installed), creates `.env` from `.env.sample` with a freshly generated `JWT_SECRET` (only if `.env` doesn't already exist — it never overwrites one), and seeds the database with the sample trips.

`npm run dev` starts the backend and the admin frontend together, with labeled output for each: the customer-facing site and API at http://localhost:3000, and the admin SPA at http://localhost:4200. Open both URLs in your browser to confirm everything is running.

### Manual setup (what the quick start does for you)

These are the same steps `npm run setup` and `npm run dev` perform automatically. Use them if you want to run each piece by hand, or if the quick start script stops with an error you need to work around.

1. **Install prerequisites.** You need [Node.js](https://nodejs.org/) and a local MongoDB server running on `127.0.0.1` (the default install/port). Start MongoDB before continuing.
2. **Install backend dependencies.** From the `travlr/` folder:
   ```
   npm install
   ```
3. **Create your environment file.** Copy `.env.sample` to `.env`:
   ```
   copy .env.sample .env
   ```
   Open `.env` and set `JWT_SECRET` to any long random string (the sample file already has a placeholder value you can keep or replace). The file also holds `ADMIN_APP_URL`, the address the customer pages link to for the React catalog application; leave it at `http://localhost:4200` for local use.
4. **Seed the database.** From `travlr/`:
   ```
   node app_api/models/seed.js
   ```
   This loads 27 sample trips into MongoDB. Re-run this command any time you reset the database or after pulling changes that alter the trip schema.
5. **Start the backend.** From `travlr/`:
   ```
   npm start
   ```
   The customer-facing site is now at http://localhost:3000, and the API is available under http://localhost:3000/api.
6. **Install and start the admin frontend.** In a second terminal, from `travlr/app_react`:
   ```
   npm install
   npm run dev
   ```
   The admin SPA is now at http://localhost:4200.
7. **Open both URLs in your browser** to confirm everything is running: http://localhost:3000 (customer site) and http://localhost:4200 (admin app).

## Using the app

**As a visitor**, open http://localhost:3000 to browse the server-rendered customer site: a Home page with featured trips, a full Travel catalog, an About page, and a Contact page with a working form. Every trip on the Home and Travel pages shows its resort, departure date, length, and per-person price, and each trip on the Travel page has a "Book this trip" panel that opens in place. Sending that form stores a booking request — an enquiry naming the trip, the visitor, and the number of travellers, with no payment information — and shows a confirmation page. Both pages also link to the React catalog application for keyword search, filtering, recommendations, and rating; that link's address is the `ADMIN_APP_URL` setting, which defaults to http://localhost:4200. The richer catalog interface is the React app at http://localhost:4200, and it works without logging in: search by keyword, sort results (by name, price, or start date), page through the catalog, and view "Similar to" recommendations for a given trip based on price, rating, trip length, and shared description vocabulary.

**To create an account**, go to the admin app at http://localhost:4200 and use the Register page. Every account created through Register starts as a standard (non-admin) user, regardless of what is submitted.

**To log in**, the login form requires the Name, Email, and Password fields to all be filled in — submitting with any one of them blank is rejected client-side with an error message. Email addresses are stored in lowercase, so log in with the same casing you registered with (or any casing — matching is case-insensitive because of the lowercase storage).

**To promote an account to admin**, run the following from the `travlr/` folder, substituting the email you registered with:
```
node scripts/promote-admin.js your@email.com
```
Then log out and log back in through the admin app. Admin status is carried in the login token, so a fresh login is required after promotion — an already-open session will not pick up the new role.

**Once logged in** (any account, admin or not), each trip card in the catalog app shows five clickable stars — rate a trip from one to five, change your rating any time, one rating per account per trip. Community averages appear on the trip cards and on the customer site's Travel page.

**Once logged in as admin**, the admin app shows "Add Trip" and "Edit" controls that are hidden from standard users. Non-admin accounts can still log in and view data through the API, but trip creation, editing, and deletion are blocked server-side as well as hidden in the UI.

## Running the tests

Backend tests (from `travlr/`):
```
npm test
```
Runs 96 Jest tests against the Express API and algorithms. On a cold start (first run after installing or after a machine restart), the in-memory MongoDB test database can occasionally fail to initialize in time and one test run may fail — if that happens, simply run `npm test` again.

Frontend tests (from `travlr/app_react`):
```
npm test
```
Runs 32 Jest/React Testing Library tests.

Also from `travlr/app_react`, you can confirm the TypeScript compiles cleanly and the production bundle builds:
```
npx tsc --noEmit
npm run build
```
Both should complete with no errors.

## Running it on a public server

`DEPLOYMENT.md` in this folder is a step-by-step guide to putting the application on an Ubuntu server reachable over HTTPS: the machine, the database, the backend as a managed service, the admin application built to static files, and a web server that obtains and renews its own certificate. The admin application's API address is set when the bundle is built (`VITE_API_BASE_URL`); with nothing set it stays at the local default, so nothing about local development changes.

## Dependencies and known advisories

Both dependency trees are kept clear of published security advisories as far as that is possible without breaking changes. You can check the current state yourself:

```
npm audit
```

From `travlr/` this reports no vulnerabilities. From `travlr/app_react` it reports four, all of which were reviewed and deliberately left in place:

| Package | Advisory | Why it is left as is |
|---|---|---|
| `esbuild`, `vite` | A website open in the same browser can read responses from the Vite development server | Affects the development server only. It is never run in production, and the built bundle does not contain either package. Clearing it requires a major Vite upgrade. |
| `react-router`, `react-router-dom` | Open redirect through a backslash in a link target; unsafe object construction during server-side-rendering hydration | Neither applies here. Link targets in this application are fixed strings, never values supplied by a user, and the application does no server-side rendering. The fixed release is a major version whose upgrade breaks the existing test suite. |

The backend dependency list was also cleaned of a package named `crypto`. That is an abandoned placeholder on the public registry that shadows Node's own built-in module of the same name; removing it makes `require('crypto')` resolve to the module Node ships.

## Where each enhancement lives

| Enhancement | What changed | Where |
|---|---|---|
| Software design and engineering | Angular admin SPA replaced with React 18 + strict TypeScript; centralized Express error handling; security fixes; one-command setup and run (`npm run setup` / `npm run dev`); completed customer site (Home, Travel, About, a Contact page whose form stores messages, trip facts on every listing, a per-trip booking-request form, and a link through to the catalog application) | `app_react/` (whole folder); Express error-handling middleware and `asyncHandler` pattern in the backend routes/controllers; `scripts/setup.js`; `app_server/` views, controllers, and `app_server/lib/tripView.js`; `app_api/models/bookingRequest.js` and `app_api/controllers/bookings.js` (`POST /api/bookings`) |
| Algorithms and data structures | Stable merge sort, bounded min-heap top-k recommendations, field-weighted relevance search, cursor-based pagination, trie-backed search suggestions (`GET /api/trips/suggest`) | `app_api/algorithms/` (`mergeSort.js`, `minHeap.js`, `relevance.js`, `cursor.js`, `trie.js`) |
| Databases | Aggregation-pipeline query engine with `?engine=db|app` switch, database-side price and star-rating filters, community trip ratings with database-computed averages and a unique one-rating-per-user index, Mongoose schema validation, weighted text index plus a price index, catalog stats endpoint, role-based access control, NoSQL-injection sanitization, tightened CORS | `app_api/controllers/tripsDb.js`, `app_api/controllers/ratings.js`, `app_api/models/travlr.js`, `app_api/models/tripRating.js`, `GET /api/trips/stats`, admin JWT role claim, sanitization middleware |

## Troubleshooting

- **The app won't start / API calls fail:** make sure MongoDB is running on `127.0.0.1` before running `npm start` or `npm run setup`. Both the backend and the seed script need a live database connection. `npm run setup` checks for MongoDB first and stops with a plain-language error if it can't reach it, so a failure there almost always means MongoDB isn't running yet.
- **"Port already in use" when starting the backend or frontend:** something else is already listening on port 3000 (backend) or 4200 (frontend, the dev server). Stop that process, or find what owns the port before trying again — don't just pick a different port, since the two sides expect each other at these fixed addresses.
- **Login is rejected before it even reaches the server:** the login form requires Name, Email, and Password to all be filled in; a blank field is rejected client-side with an error message.
- **Data looks wrong or missing after a schema or code change:** re-run `node app_api/models/seed.js` from `travlr/` to reload the sample trips.
- **The very first `npm test` run is slow or reports failures, then passes on the second run:** the backend tests run against an in-memory MongoDB whose server executable (about 75 MB) is downloaded on first use into the system temporary folder. If the download is still in progress when a test suite's startup deadline expires, that first run fails; run `npm test` again once and it will pass. The executable is stored in the temporary folder deliberately — its path stays short there, which avoids Windows' 260-character path limit no matter how deeply nested the project folder is.
- **`npm run setup` stops during dependency installation:** the message names the folder it was working in and either the reason the command could not be started or the exit code it returned, and npm's own output is printed directly above it. Run `npm install` by hand in the folder named in the message to see the same output on its own.
